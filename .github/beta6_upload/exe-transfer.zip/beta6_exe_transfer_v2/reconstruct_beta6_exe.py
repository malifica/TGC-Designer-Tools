from pathlib import Path
import struct,hashlib,json,zlib,marshal,sys
MAG=b"MEI\x0c\x0b\x0a\x0b\x0e"
def sha(b): return hashlib.sha256(b).hexdigest()
def parse_outer(b):
 ci=b.rfind(MAG);
 if ci<0: raise SystemExit("PyInstaller cookie not found")
 _,pkg,tp,tl,_,_=struct.unpack("!8sIIII64s",b[ci:ci+88]); st=len(b)-pkg; pos=st+tp; end=pos+tl; d={}
 while pos<end:
  el,off,cl,ul,cf,tc=struct.unpack("!IIIIBB",b[pos:pos+18]); n=b[pos+18:pos+el].split(b"\0",1)[0].decode("utf8","replace"); d[n]=(off,cl,ul,cf,tc,b[st+off:st+off+cl]); pos+=el
 return st,d
def parse_outer_toc(toc):
 pos=0; out=[]
 while pos<len(toc):
  el,off,cl,ul,cf,tc=struct.unpack("!IIIIBB",toc[pos:pos+18]); n=toc[pos+18:pos+el].split(b"\0",1)[0].decode("utf8","replace"); out.append((n,off,cl,ul,cf,tc)); pos+=el
 return out
def parse_pyz(blob):
 off=struct.unpack("!I",blob[8:12])[0]; toc=marshal.loads(blob[off:]); return {n:(typ,pos,ln,blob[pos:pos+ln]) for n,(typ,pos,ln) in toc}
root=Path(__file__).resolve().parent; m=json.loads((root/"manifest.json").read_text()); base=Path(sys.argv[1]).read_bytes(); wheelroot=Path(sys.argv[2]); out=Path(sys.argv[3])
if len(base)!=m["base_size"] or sha(base)!=m["base_sha256"]: raise SystemExit("Base EXE identity mismatch")
bst,bouter=parse_outer(base); bpyz=parse_pyz(bouter["PYZ.pyz"][5])
# target TOC comes directly from exact tested EXE payload tail
tail=(root/"outer_tail.bin").read_bytes(); target_toc=parse_outer_toc(tail[:m["toc_len"]])
# exact target PYZ
pl=(root/"pyz_local.bin").read_bytes(); ptoc=(root/"pyz_toc.bin").read_bytes(); ttoc=marshal.loads(ptoc); pyz=bytearray((root/"pyz_header.bin").read_bytes())
for name,(typ,pos,ln) in ttoc:
 if len(pyz)!=pos: raise SystemExit(f"PYZ offset mismatch: {name}")
 if name in m["pyz_local"]:
  x=m["pyz_local"][name]; data=pl[x["offset"]:x["offset"]+x["length"]]
  if sha(data)!=x["sha256"]: raise SystemExit(f"PYZ local payload mismatch: {name}")
 else:
  data=bpyz[name][3]
 if len(data)!=ln: raise SystemExit(f"PYZ size mismatch: {name}")
 pyz+=data
pyz+=ptoc; pyz=bytes(pyz)
local=(root/"outer_local.bin").read_bytes(); target=bytearray((root/"prefix.bin").read_bytes())
if len(target)!=m["archive_start"]: raise SystemExit("Prefix size mismatch")
for name,off,cl,ul,cf,tc in target_toc:
 if len(target)-m["archive_start"]!=off: raise SystemExit(f"CArchive offset mismatch: {name}")
 if name=="PYZ.pyz": data=pyz
 elif name in m["outer_local"]:
  x=m["outer_local"][name]; data=local[x["offset"]:x["offset"]+x["length"]]
  if sha(data)!=x["sha256"]: raise SystemExit(f"Outer local payload mismatch: {name}")
 elif name in m["wheel_files"]:
  x=m["wheel_files"][name]; fp=wheelroot/Path(name.replace("\\","/"));
  if not fp.is_file(): raise SystemExit(f"Missing wheel file: {fp}")
  raw=fp.read_bytes()
  if len(raw)!=x["raw_size"] or sha(raw)!=x["raw_sha256"]: raise SystemExit(f"Wheel source identity mismatch: {name}")
  data=zlib.compress(raw,9) if cf else raw
 else: data=bouter[name][5]
 if len(data)!=cl: raise SystemExit(f"CArchive size mismatch: {name}: {len(data)} != {cl}")
 target+=data
target+=tail; target=bytes(target)
if len(target)!=m["target_size"] or sha(target)!=m["target_sha256"]: raise SystemExit(f"Final EXE mismatch: size={len(target)} sha256={sha(target)}")
out.write_bytes(target); print(f"PASS exact Beta 6 EXE: {len(target)} bytes SHA-256 {sha(target)}")
