# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['tgc_gui.py'],
    pathex=[],
    binaries=[('laszip/laszip-cli.exe', 'laszip'), ('tgc_lidar_fast_native.dll', '.')],
    datas=[('tree_profiles', 'tree_profiles')],
    hiddenimports=[],
    hookspath=['PyInstaller/hooks'],
    hooksconfig={},
    runtime_hooks=['PyInstaller/rthook_rasterio.py'],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='tgc_gui_2k25_beta6',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
