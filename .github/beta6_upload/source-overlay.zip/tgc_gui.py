import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import *
import tkinter.ttk as ttk
from tkinter.scrolledtext import ScrolledText

import copy
import queue
import threading
import traceback
import cv2
from functools import partial
import math
from pathlib import Path
import numpy as np
import numpy
from PIL import Image, ImageTk
import string

import tgc_definitions
import tree_profile_manager
import tgc_tools
import osm_alignment_viewer
import osm_mask_alignment
import osm_custom_layout
import auto_red_mask
import lidar_map_api
import usgs_ept_downloader
import dem_map_api
import tgc_image_terrain
from tgc_visualizer import drawCourseAsImage
import OSMTGC

TGC_GUI_VERSION = "v0.5.0-2k25-beta6"
TGC_APP_TITLE = "TGC Designer Tools 2K25 - Beta 6"

AUTO_RED_MASK_BUFFER_MIN_M = 5.0
AUTO_RED_MASK_BUFFER_MAX_M = 30.0
AUTO_RED_MASK_BUFFER_DEFAULT_M = 5.0
AWS_EPT_OSM_BUFFER_M = 150.0

image_width = 500
image_height = 500

# Make placeholder image
data=numpy.array(numpy.random.random((image_width,image_height))*100,dtype=int)
iim=Image.frombytes('L', (data.shape[1],data.shape[0]), data.astype('b').tobytes())

root = None
canvas = None
canvas_image = None
course_json = None

scorecard = None
inner_frame = None # Scorecard inner frame
course_version = -1
brush_scale_combo = None
dem_processing_active = False
lidar_processing_active = False

# TGC_BETA6_CFS_MASK_ALIGNMENT_WORKFLOW_V1
last_alignment_heightmap_dir = None
osm_mask_status_var = None
osm_mask_status_label = None
# TGC_BETA6_CFS_ASYNC_MASK_REBUILD_V3
# TGC_BETA6_CUSTOM_UNMATCHED_OSM_V5
mask_rebuild_active = False

# TGC_BETA6_CUSTOM_UNMATCHED_OSM_V5_1
# Custom / Unmatched must be visible during the initial LiDAR/DEM crop preview,
# not only after heightmap generation in CFS.  Keep the terrain CRS authoritative
# and draw the detached OSM through the same metric placement helper used later.
def _load_custom_preview_osm(local_osm_file, printf=print):
    path = str(local_osm_file or "").strip()
    if not path:
        return None
    try:
        xml_text = Path(path).read_text(encoding="utf-8")
    except UnicodeDecodeError:
        xml_text = Path(path).read_text(encoding="utf-8-sig")
    result = OSMTGC.parseOSMData(xml_text, printf=printf)
    if result is None:
        raise RuntimeError("Could not parse the Custom / Unmatched Local OSM file.")

    incomplete = []
    for way in getattr(result, "ways", []) or []:
        try:
            way.get_nodes(resolve_missing=False)
        except Exception:
            incomplete.append(getattr(way, "id", "?"))
    if incomplete:
        preview = ", ".join(str(x) for x in incomplete[:10])
        if len(incomplete) > 10:
            preview += ", ..."
        raise RuntimeError(
            "Custom / Unmatched Local OSM contains " + str(len(incomplete)) +
            " incomplete ways with missing node references: " + preview
        )
    return result


def _custom_preview_pointcloud(base_pc, osm_result):
    origin = base_pc.origin
    target_center_x = float(origin[0]) + float(base_pc.width) * 0.5
    target_center_y = float(origin[1]) + float(base_pc.height) * 0.5
    placement = osm_custom_layout.build_custom_placement(
        osm_result,
        target_center_x,
        target_center_y,
    )
    return osm_custom_layout.CustomTGCPointCloud(base_pc, placement), placement


def _apply_custom_unmatched_preview_overlay(
    prepared,
    local_osm_file,
    preview_kind,
    auto_red_mask_enabled=False,
    auto_red_mask_buffer_m=5.0,
    printf=print,
):
    if prepared is None or not local_osm_file:
        return prepared

    osm_result = _load_custom_preview_osm(local_osm_file, printf=printf)
    if osm_result is None:
        return prepared

    if preview_kind == "lidar":
        base_pc = prepared["pc"]
        image = prepared["course_image"]
        image_scale = float(prepared["sample_scale"])
        image_key = "course_image"
    elif preview_kind == "dem":
        base_pc = prepared["pc"]
        image = prepared["boundary_preview_rgb"]
        image_scale = float(prepared["boundary_preview_image_scale"])
        image_key = "boundary_preview_rgb"
    else:
        raise ValueError("Unknown custom preview kind: " + str(preview_kind))

    custom_pc, placement = _custom_preview_pointcloud(base_pc, osm_result)
    info = placement.diagnostics()
    printf(
        "Custom / Unmatched OSM preview: centered course anchor " +
        str(info.get("anchor_strategy", "layout")) + " (" +
        str(int(info.get("anchor_node_count", 0))) + " node(s), " +
        str(round(float(info["source_width_m"]), 1)) + " x " +
        str(round(float(info["source_height_m"]), 1)) +
        " m) on the " + str(preview_kind).upper() + " terrain preview."
    )

    image = OSMTGC.addOSMToImage(
        osm_result.ways,
        image,
        custom_pc,
        image_scale,
        printf=printf,
    )
    if bool(auto_red_mask_enabled):
        image = auto_red_mask.apply_auto_red_mask(
            osm_result,
            image,
            custom_pc,
            image_scale,
            buffer_m=float(auto_red_mask_buffer_m),
            printf=printf,
        )
    prepared[image_key] = image
    # Keep this separate from osm_result.  The normal LiDAR/DEM output writer
    # must not reuse detached OSM with an ordinary geographic point cloud.
    prepared["custom_preview_osm_result"] = osm_result
    prepared["custom_preview_placement"] = info
    return prepared


def drawPlaceholder():
    global root
    global canvas
    global canvas_image
    # TGC_DYNAMIC_COURSE_PREVIEW_V1
    # Restore the normal square placeholder while the course preview is busy.
    try:
        image_frame.configure(width=image_width, height=image_height)
        canvas.configure(width=image_width, height=image_height)
    except Exception:
        pass
    default_im = ImageTk.PhotoImage(image=iim)
    canvas.img = default_im
    canvas.itemconfig(canvas_image, image = default_im)
    root.update()

def getCourseVersion(course_json):
    course_version = -1

    if 'useV43AltSurfaceSplineScale' in course_json and 'holes3' in course_json:
        course_version = 25
    elif 'useV30Rough' in course_json and 'holes2' in course_json:
        course_version = 23
    elif 'useV19DetailPlacement' in course_json and 'holes' in course_json:
        course_version = 19

    return course_version

def scorecardSumList(l):
    front = 0
    back = 0
    total = 0
    output = []
    for i in range(0, len(l)):
        value = math.ceil(l[i])
        total += value
        if i < 9:
            front += value
        else:
            back += value
        output.append(value)
        if i == 8:
            output.append(front)
    if back > 0:
        output.append(back)
    output.append(total)

    return output

def drawScorecard(course_json):
    global scorecard
    global inner_frame
    global course_version
    
    # Which Tkinter colors to draw on the chart
    hole_color = "snow"
    par_color = "bisque"
    pin_color = "gray40"
    tee_color_order = course_json["teeColours"]
    tee_colors_dict = {
        "red":"firebrick1",
        "white":"floral white",
        "blue":"navy",
        "black":"gray10",
        "green":"dark green",
        "gold":"gold"
    }
    tee_text_colors_dict = {
        "red":"black",
        "white":"black",
        "blue":"white",
        "black":"white",
        "green":"white",
        "gold":"black"
    }

    # Determine tee colors for chart
    tee_colors = []
    tee_text_colors = []
    for color in tee_color_order:
        color_name = tgc_definitions.tee_colors[color]
        tee_colors.append(tee_colors_dict[color_name])
        tee_text_colors.append(tee_text_colors_dict[color_name])

    # Clear the chart each time the course is redrawn
    if inner_frame is not None:
        inner_frame.destroy()
    inner_frame = Frame(scorecard, bg="darkgrey")
    inner_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    # Par and yardages values from holes
    pars, pin_counts, tees = tgc_tools.get_hole_information(course_json, course_version)

    # Determine number of valid tee sets
    # And fill in missing information for tees that weren't placed
    valid_tees = []
    for tee in tees:
        empty_tee = all(v is None for v in tee)
        if not empty_tee:
            valid_tees.append(tee)
    
    for i in range(0, len(pars)):
        last_valid_distance = 0.0
        for j in range(0, len(valid_tees)):
            if valid_tees[j][i] is not None:
                last_valid_distance = valid_tees[j][i]
            else:
                valid_tees[j][i] = last_valid_distance

    scorecard_pars = scorecardSumList(pars)
    scorecard_tees = []
    for t in valid_tees:
        scorecard_tees.append(scorecardSumList(t))

    # Generate top holes label and pin counts
    holes = []
    pins = []
    for i in range(0, len(pars)):
        holes.append(i+1)
        pins.append(pin_counts[i])
        if i == 8:
            holes.append("out")
            pins.append("")
    if len(pars) > 9:
        holes.append("in")
        pins.append("")
    holes.append("tot")
    pins.append("")

    h = Entry(inner_frame, justify='center', fg="black", readonlybackground=hole_color, width=10)
    h.insert(0, "HOLE")
    h.configure(state="readonly")
    h.grid(row=0, column=0)

    h = Entry(inner_frame, justify='center', fg="black", readonlybackground=par_color, width=10)
    h.insert(0, "PAR")
    h.configure(state="readonly")
    h.grid(row=1, column=0)

    h = Entry(inner_frame, justify='center', fg="black", readonlybackground=pin_color, width=10)
    h.insert(0, "NUM PINS")
    h.configure(state="readonly")
    h.grid(row=2, column=0)

    for j in range(0, len(scorecard_tees)):
        h = Entry(inner_frame, justify='center', fg=tee_text_colors[j], readonlybackground=tee_colors[j], width=10)
        h.insert(0, "TEE SET")
        h.configure(state="readonly")
        h.grid(row=3+j, column=0)

    for i in range(0, len(holes)):
        # Append hole numbers
        h = Entry(inner_frame, justify='center', fg="black", readonlybackground=hole_color, width=5)
        h.insert(0, str(holes[i]))
        h.configure(state="readonly")
        h.grid(row=0, column=i+1)

        # Append par values
        p = Entry(inner_frame, justify='center', fg="black", readonlybackground=par_color, width=5)
        p.insert(0, str(scorecard_pars[i]))
        p.configure(state="readonly")
        p.grid(row=1, column=i+1)

        # Append number of pins - useful for working around simulator bug
        p = Entry(inner_frame, justify='center', fg="black", readonlybackground=pin_color, width=5)
        p.insert(0, str(pins[i]))
        p.configure(state="readonly")
        p.grid(row=2, column=i+1)

        # Append yardages
        for j in range(0, len(scorecard_tees)):
            p = Entry(inner_frame, justify='center', fg=tee_text_colors[j], readonlybackground=tee_colors[j], width=5)
            p.insert(0, str(scorecard_tees[j][i]))
            p.configure(state="readonly")
            p.grid(row=3+j, column=i+1)

def drawCourse(cjson):
    global root
    global canvas
    global canvas_image
    global course_version

    data = drawCourseAsImage(cjson, course_version)
    if data is None or data.size == 0:
        return

    # TGC_DYNAMIC_COURSE_PREVIEW_V1
    # Fit the dynamically sized world preview inside the existing 500x500
    # display area without distorting its aspect ratio.
    source_height, source_width = data.shape[:2]
    display_scale = min(
        float(image_width) / float(source_width),
        float(image_height) / float(source_height),
    )
    display_width = max(1, int(round(source_width * display_scale)))
    display_height = max(1, int(round(source_height * display_scale)))

    im = Image.fromarray(
        (255.0 * data).astype(np.uint8),
        'RGB'
    ).resize(
        (display_width, display_height),
        Image.NEAREST
    )
    im = im.transpose(Image.FLIP_TOP_BOTTOM)
    cim = ImageTk.PhotoImage(image=im)

    try:
        image_frame.configure(width=display_width, height=display_height)
        canvas.configure(width=display_width, height=display_height)
    except Exception:
        pass

    canvas.img = cim # Need to save reference to ImageTK
    canvas.itemconfig(canvas_image, image = cim)

    drawScorecard(cjson)
    root.update()

def getCourseDirectory(output):
    global root
    global course_json
    global course_version
    
    cdir =  tk.filedialog.askdirectory(initialdir = ".", title = "Select course directory")
    if cdir:
        root.filename = cdir
        output.config(text=root.filename)

        drawPlaceholder() # Clear out existing course while picking a new one

        try:
            course_json = tgc_tools.get_course_json(root.filename)
            name_entry.configure(state='normal')
            if course_json is not None:
                course_name_var.set(course_json["name"])
                course_version = getCourseVersion(course_json)    
                drawCourse(course_json)
        except:
            pass

def alert(msg):
    popup = tk.Toplevel()
    popup.geometry("200x200")
    popup.wm_title("Alert")
    label = ttk.Label(popup, text=msg, wraplength=200, justify=CENTER)
    label.pack(side="top", fill="x", pady=10)
    B1 = ttk.Button(popup, text="OK", command = popup.destroy)
    B1.pack()
    popup.mainloop()

def disableAllChildren(var, frame):
    for child in frame.winfo_children():
        if var.get(): # Check enabled
            child['state'] = 'normal'
        else:
            child['state'] = 'disable'

    # Also support children directly outside of a frame
    if len(frame.winfo_children()) == 0:
        if var.get(): # Check enabled
            frame['state'] = 'normal'
        else:
            frame['state'] = 'disable'

def validateCourseName(action_type, index, value, previous, new_text, validation_types, validation_type, widget_name):
    # We also can submit as long of a course name as we want, so remove this limit!
    #if len(value) > 32:
    #    return False
    return True
    # Looks like they accept almost all characters, wow...
    '''allowed_chars = string.ascii_letters + string.digits + ' '
    allowed_set = set(allowed_chars)
    valid = all(x in allowed_set for x in new_text)
    if not valid:
        return False
        course_name_var.set(previous)
    return True'''

course_types = [
    ('Golf Course Files', '*.course'), 
    ('All files', '*'), 
]

def importCourseAction():
    global root
    global course_json
    global course_version

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before importing a .course file")
        return

    input_course = tk.filedialog.askopenfilename(title='Course File', defaultextension='course', initialdir=root.filename, filetypes=course_types)

    if input_course:
        drawPlaceholder()
        tgc_tools.unpack_course_file(root.filename, input_course)
        course_json = tgc_tools.get_course_json(root.filename)
        name_entry.configure(state='normal')
        if course_json is not None:
            course_name_var.set(course_json["name"])
            course_version = getCourseVersion(course_json)
            drawCourse(course_json)

def exportCourseAction():
    global root
    global course_json

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before exporting a .course file")
        return

    if course_json is None:
        alert("Make sure to import a .course file")
        return

    dest_file = tk.filedialog.asksaveasfilename(title='Save Course As', defaultextension='.course', initialdir=root.filename, confirmoverwrite=True, filetypes=course_types)

    if dest_file:
        new_course_name = course_name_var.get()
        if len(new_course_name) > 0:
            course_json["name"] = new_course_name
            tgc_tools.set_course_metadata_name(root.filename, course_json["name"])

        # Regional theme material metadata sync.
        try:
            profile_var = options_entries_dict.get("tree_profile")
            profile_choice = profile_var.get() if profile_var is not None else None
            course_json = tree_profile_manager.apply_visual_material_preset(
                course_json,
                profile_choice,
                printf=print,
            )
            metadata_json = tgc_tools.get_metadata_json(root.filename)
            metadata_json = tree_profile_manager.apply_visual_material_preset(
                metadata_json,
                profile_choice,
                printf=print,
                metadata=True,
            )
            tgc_tools.write_metadata_json(root.filename, metadata_json)
        except Exception as exc:
            print("Warning: could not sync regional theme material metadata:", exc)

        drawPlaceholder()
        tgc_tools.pack_course_file(root.filename, None, dest_file, course_json, course_version)
        drawCourse(course_json)

def autoPositionAction():
    global course_json
    global course_version

    drawPlaceholder()
    course_json = tgc_tools.auto_position_course(course_json, course_version)
    drawCourse(course_json)

def shiftAction(ew_entry, ns_entry, stype="course"):
    global course_json
    global course_version

    try:
        easting_shift = float(ew_entry.get())
        northing_shift = float(ns_entry.get())
    except:
        print("No action taken: Could not get valid shifts from entry")
        return
    drawPlaceholder()
    if stype == "course":
        course_json = tgc_tools.shift_course(course_json, easting_shift, northing_shift, course_version)
    elif stype == "terrain":
        course_json = tgc_tools.shift_terrain(course_json, easting_shift, northing_shift, course_version)
    elif stype == "features":
        course_json = tgc_tools.shift_features(course_json, easting_shift, northing_shift, course_version)
    else:
        print("No action taken: Unknown shift type: " + stype)
    drawCourse(course_json)

def rotateAction(rotate_entry):
    global course_json
    global course_version

    try:
        rotation_degrees = float(rotate_entry.get())
        rotation = rotation_degrees * math.pi / 180.0
    except:
        print("No action taken: Could not get valid rotation from entry")
        return

    drawPlaceholder()
    course_json = tgc_tools.rotate_course(course_json, -rotation, course_version)
    drawCourse(course_json)

# TGC_HULKIFY_GUI_V2_SLOPE_LOCK
def hulkifyAction():
    global course_json
    global course_version

    if course_json is None:
        alert("Make sure to import a .course file")
        return

    # TGC_HULKIFY_10_PERCENT_V3
    factor = 1.10
    bounds = tgc_tools.get_course_horizontal_bounds(
        course_json,
        course_version,
    )
    relief = tgc_tools.get_course_vertical_relief_bounds(
        course_json,
        course_version,
    )
    if bounds is None:
        alert("The loaded course contains no horizontal geometry to scale.")
        return

    before_width = float(bounds["width"])
    before_height = float(bounds["height"])
    after_width = before_width * factor
    after_height = before_height * factor
    relief_before = float((relief or {}).get("range", 0.0) or 0.0)
    relief_after = relief_before * factor
    relief_datum = float((relief or {}).get("datum", 0.0) or 0.0)

    previous = course_json.get("malificaHulkify", {})
    previous_count = 0
    previous_factor = 1.0
    previous_vertical = 1.0
    if isinstance(previous, dict):
        try:
            previous_count = int(previous.get("applicationCount", 0) or 0)
        except Exception:
            previous_count = 0
        try:
            previous_factor = float(previous.get("combinedFactor", 1.0) or 1.0)
        except Exception:
            previous_factor = 1.0
        try:
            previous_vertical = float(previous.get("verticalScale", 1.0) or 1.0)
        except Exception:
            previous_vertical = 1.0

    repeat_note = ""
    if previous_count > 0:
        repeat_note = (
            "\n\nThis course has already been Hulkified " +
            str(previous_count) + " time(s), with a recorded combined "
            "horizontal factor of " + str(round(previous_factor, 4)) + "."
        )
        if previous_vertical <= 1.000001:
            repeat_note += (
                " It appears to have been created by the older horizontal-only "
                "Hulkify. Re-import the original course before using this "
                "slope-locked version, or the horizontal enlargement will compound."
            )
        else:
            repeat_note += " Another click compounds both horizontal size and relief."

    prompt = (
        "Scale the complete course by 10% while preserving terrain slopes?\n\n"
        "Horizontal span: " +
        str(round(before_width, 1)) + " x " +
        str(round(before_height, 1)) + " m\n"
        "After Hulkify: " +
        str(round(after_width, 1)) + " x " +
        str(round(after_height, 1)) + " m\n\n"
        "Terrain relief: " + str(round(relief_before, 1)) + " m -> " +
        str(round(relief_after, 1)) + " m\n"
        "Relief datum (kept fixed): " + str(round(relief_datum, 2)) + " m\n\n"
        "X/Z positions and horizontal footprints will scale 1.10x. Absolute "
        "terrain targets, relative height edits, active native-water planes, "
        "and placed-object Y positions will receive the matching vertical "
        "relief transform. This keeps rise/run and slope percentages the same. "
        "Placed-object model sizes will not change."
        + repeat_note +
        "\n\nThe change is in memory until you use Export .course."
    )

    if not messagebox.askyesno(
        "Hulkify Course (+10% Slope-Locked)",
        prompt,
        parent=root,
    ):
        return

    original_course = copy.deepcopy(course_json)
    try:
        drawPlaceholder()
        course_json = tgc_tools.scale_course_horizontal(
            course_json,
            factor=factor,
            course_version=course_version,
            printf=print,
            preserve_slopes=True,
        )
        drawCourse(course_json)
    except Exception as exc:
        course_json = original_course
        try:
            drawCourse(course_json)
        except Exception:
            pass
        traceback.print_exc()
        messagebox.showerror(
            "Hulkify Course failed",
            "No course changes were retained.\n\n" + str(exc),
            parent=root,
        )
        return

    messagebox.showinfo(
        "Hulkify complete",
        (
            "The course is now 10% larger in X/Z and its terrain relief was "
            "scaled to retain the original slope severity.\n\n"
            "Use Export .course to save the result. Re-import the original "
            "course to undo the in-memory change."
        ),
        parent=root,
    )

def elevateAction(elevate_entry, auto=False):
    global course_json
    global course_version

    elevation_shift = None
    if not auto:
        try:
            elevation_shift = float(elevate_entry.get())
        except:
            print("No action taken: Could not get valid elevation shift from entry")
            return

    if elevation_shift is not None and elevation_shift == 0.0:
        # Need to not pass in 0.0 or auto elevation shift will be triggered
        print("No action taken: shift requested was zero")
        return

    drawPlaceholder()
    course_json = tgc_tools.elevate_terrain(course_json, elevation_shift, course_version=course_version)
    drawCourse(course_json)

numpy_types = [
    ('Golf Course Features', '*.npy'), 
    ('All files', '*'), 
]
numpy_terrain_types = [
    ('Golf Course Terrain', '*.terrain.npy'), 
    ('All files', '*'), 
]
numpy_holes_types = [
    ('Golf Course Holes', '*.holes.npy'), 
    ('All files', '*'), 
]

def separateAction(stype="terrain"):
    global course_json
    global course_version

    if stype == "terrain":
        name = "Terrain"
        f = tgc_tools.strip_terrain
        ext = ".terrain.npy"
        filetypes = numpy_terrain_types
    elif stype == "holes":
        name = "Holes"
        f = tgc_tools.strip_holes
        ext = ".holes.npy"
        filetypes = numpy_holes_types
    else:
        print("No action taken: Unknown separate type: " + stype)
        return

    dest_file = tk.filedialog.asksaveasfilename(title=name+' filename', defaultextension=ext, initialdir=root.filename, confirmoverwrite=True, filetypes=filetypes)

    if dest_file:
        drawPlaceholder()
        course_json = f(course_json, dest_file, course_version)
        drawCourse(course_json)

def insertAction(stype="terrain"):
    global course_json
    global course_version

    if stype == "terrain":
        name = "Terrain"
        f = tgc_tools.insert_terrain
        ext = ".terrain.npy"
        filetypes = numpy_terrain_types
    elif stype == "holes":
        name = "Holes"
        f = tgc_tools.insert_holes
        ext = ".holes.npy"
        filetypes = numpy_holes_types
    else:
        print("No action taken: Unknown insert type: " + stype)
        return

    input_file = tk.filedialog.askopenfilename(title=name+' filename', defaultextension=ext, initialdir=root.filename, filetypes=filetypes)

    if input_file:
        drawPlaceholder()
        course_json = f(course_json, input_file, course_version)
        drawCourse(course_json)

def confirmCourse(popup, new_course_json):
    global course_json

    popup.destroy()

    drawPlaceholder()
    if  new_course_json is not None:
        course_json = new_course_json
    drawCourse(course_json)

def combineAction():
    global course_json
    other_course_dir = tk.filedialog.askdirectory(initialdir = ".", title = "Select second course directory")

    if other_course_dir:
        drawPlaceholder()
        course1_json = copy.deepcopy(course_json) # Make copy so this isn't "permanent" in memory
        course2_json = tgc_tools.get_course_json(other_course_dir)

        course1_json = tgc_tools.merge_courses(course1_json, course2_json)
        drawCourse(course1_json)

        popup = tk.Toplevel()
        popup.geometry("400x400")
        popup.wm_title("Confirm course merge?")
        label = ttk.Label(popup, text="Confirm course merge?")
        label.pack(side="top", fill="x", pady=10)
        B1 = ttk.Button(popup, text="Yes, Merge", command = partial(confirmCourse, popup, course1_json))
        B1.pack()
        B2 = ttk.Button(popup, text="No, Abandon Merge", command = partial(confirmCourse, popup, None))
        B2.pack()
        popup.mainloop()

def rightClickMenu(e):
    try:
        def rClick_Copy(e, apnd=0):
            e.widget.event_generate('<Control-c>')

        def rClick_CopyAll(e, apnd=0):
            e.widget.event_generate('<Control-a>')
            e.widget.event_generate('<Control-c>')

        e.widget.focus()

        nclst=[('Copy', lambda e=e: rClick_Copy(e)),
               ('Copy All', lambda e=e: rClick_CopyAll(e))]

        rmenu = Menu(None, tearoff=0, takefocus=0)

        for (txt, cmd) in nclst:
            rmenu.add_command(label=txt, command=cmd)

        rmenu.tk_popup(e.x_root+40, e.y_root+10,entry="0")

    except TclError:
            pass

    return "break"

def tkinterPrintFunction(root, textfield, message):
    textfield.configure(state='normal')
    textfield.insert(tk.END, message + "\n")
    textfield.configure(state='disabled')
    textfield.see(tk.END)
    textfield.bind('<Button-3>', rightClickMenu, add='')
    root.update()

def getAutoRedMaskSettings(auto_red_mask_var=None, auto_red_mask_buffer_var=None):
    """Read and validate Auto Red Mask GUI settings on the Tk thread."""
    enabled = (
        bool(auto_red_mask_var.get())
        if auto_red_mask_var is not None else False
    )

    # Keep the historical +5 m behavior when the mask is disabled or when an
    # older caller does not provide the new buffer control.
    if not enabled or auto_red_mask_buffer_var is None:
        return enabled, AUTO_RED_MASK_BUFFER_DEFAULT_M

    try:
        buffer_m = float(auto_red_mask_buffer_var.get())
    except Exception:
        alert(
            "Auto Red Mask buffer must be a numeric value from "
            "5 to 30 meters."
        )
        return None

    if (
        not math.isfinite(buffer_m)
        or buffer_m < AUTO_RED_MASK_BUFFER_MIN_M
        or buffer_m > AUTO_RED_MASK_BUFFER_MAX_M
    ):
        alert(
            "Auto Red Mask buffer must be between 5 meters (minimum) "
            "and 30 meters (maximum)."
        )
        return None

    return enabled, buffer_m


def _mask_option_value(options_entries_dict, key, default=None):
    entry = options_entries_dict.get(key)
    if entry is None:
        return default
    try:
        return entry.get()
    except Exception:
        return default


def _setOSMMaskStatus(text, color="black"):
    global osm_mask_status_var
    global osm_mask_status_label

    if osm_mask_status_var is not None:
        try:
            osm_mask_status_var.set(str(text))
        except Exception:
            pass
    if osm_mask_status_label is not None:
        try:
            # Status wording carries CURRENT / STALE / INVALID explicitly.
            # Keep the text black for reliable readability on the light strip.
            osm_mask_status_label.configure(fg="black")
        except Exception:
            pass


def _currentOSMMaskInputs(
    options_entries_dict,
    osm_file_override=None,
    ew_override=None,
    ns_override=None,
):
    use_osm = bool(_mask_option_value(options_entries_dict, "use_osm", True))
    local_osm_file = str(
        osm_file_override
        if osm_file_override is not None
        else (_mask_option_value(options_entries_dict, "local_osm_file", "") or "")
    ).strip()

    try:
        adjust_ew = float(
            ew_override
            if ew_override is not None
            else _mask_option_value(options_entries_dict, "adjust_ew", 0.0)
        )
        adjust_ns = float(
            ns_override
            if ns_override is not None
            else _mask_option_value(options_entries_dict, "adjust_ns", 0.0)
        )
    except Exception:
        raise ValueError("CFS E/W and N/S alignment values must be valid numbers.")

    auto_red_enabled = bool(
        _mask_option_value(
            options_entries_dict,
            "auto_red_mask_enabled",
            False,
        )
    )
    if auto_red_enabled:
        try:
            auto_red_buffer_m = float(
                _mask_option_value(
                    options_entries_dict,
                    "auto_red_mask_buffer_m",
                    AUTO_RED_MASK_BUFFER_DEFAULT_M,
                )
            )
        except Exception:
            raise ValueError(
                "Auto Red Mask buffer must be a numeric value from 5 to 30 meters."
            )
        if (
            not math.isfinite(auto_red_buffer_m)
            or auto_red_buffer_m < AUTO_RED_MASK_BUFFER_MIN_M
            or auto_red_buffer_m > AUTO_RED_MASK_BUFFER_MAX_M
        ):
            raise ValueError(
                "Auto Red Mask buffer must be between 5 and 30 meters."
            )
    else:
        auto_red_buffer_m = AUTO_RED_MASK_BUFFER_DEFAULT_M

    include_vehicle_roads = bool(
        _mask_option_value(options_entries_dict, "road", False)
    )
    custom_unmatched_osm = bool(
        _mask_option_value(options_entries_dict, "custom_unmatched_osm", False)
    )

    return {
        "use_osm": use_osm,
        "local_osm_file": local_osm_file,
        "adjust_ew": adjust_ew,
        "adjust_ns": adjust_ns,
        "auto_red_mask_enabled": bool(auto_red_enabled),
        "auto_red_mask_buffer_m": float(auto_red_buffer_m),
        "include_vehicle_roads": include_vehicle_roads,
        "custom_unmatched_osm": custom_unmatched_osm,
    }


def refreshOSMMaskAlignmentStatus(
    options_entries_dict,
    heightmap_dir_path=None,
    printf=None,
):
    global last_alignment_heightmap_dir

    if heightmap_dir_path:
        last_alignment_heightmap_dir = str(heightmap_dir_path)

    try:
        values = _currentOSMMaskInputs(options_entries_dict)
    except Exception as exc:
        _setOSMMaskStatus(
            "OSM alignment mask: INVALID SETTINGS - " + str(exc),
            "#a00000",
        )
        return {
            "state": "invalid",
            "ok_for_import": False,
            "message": str(exc),
        }

    if not values["use_osm"]:
        _setOSMMaskStatus(
            "OSM alignment mask: not required (OpenStreetMap import disabled)",
            "grey25",
        )
        return {
            "state": "not_required",
            "ok_for_import": True,
            "message": "OpenStreetMap import is disabled.",
        }

    if not values["local_osm_file"]:
        _setOSMMaskStatus(
            "OSM alignment mask: online OSM / no Local OSM alignment record",
            "grey25",
        )
        return {
            "state": "not_required",
            "ok_for_import": True,
            "message": "No Local OSM file is selected.",
        }

    if not last_alignment_heightmap_dir:
        _setOSMMaskStatus(
            "OSM alignment mask: select a heightmap folder to verify",
            "#805500",
        )
        return {
            "state": "unknown",
            "ok_for_import": False,
            "message": "Select a heightmap folder to verify the aligned mask.",
        }

    status = osm_mask_alignment.get_alignment_status(
        last_alignment_heightmap_dir,
        values["local_osm_file"],
        values["adjust_ew"],
        values["adjust_ns"],
        values["auto_red_mask_enabled"],
        values["auto_red_mask_buffer_m"],
        include_vehicle_roads=values["include_vehicle_roads"],
        custom_unmatched_osm=values["custom_unmatched_osm"],
    )

    state = status.get("state")
    if state == "current":
        _setOSMMaskStatus(
            "OSM alignment mask: CURRENT - manual mask edits are preserved",
            "#006400",
        )
    elif state == "legacy_zero_shift":
        _setOSMMaskStatus(
            "OSM alignment mask: LEGACY ZERO-SHIFT - adopt or rebuild before import",
            "#805500",
        )
    else:
        _setOSMMaskStatus(
            "OSM alignment mask: STALE - " + str(status.get("message", "rebuild required")),
            "#a00000",
        )

    if printf is not None:
        try:
            printf("OSM alignment mask status: " + str(status.get("message", state)))
        except Exception:
            pass
    return status


def invalidateOSMMaskAlignmentAfterProcessing(
    heightmap_dir_path,
    reason,
    options_entries_dict,
    printf,
):
    """Mark the final-alignment record stale after a processor rewrites mask.png."""
    global last_alignment_heightmap_dir
    try:
        invalidated = osm_mask_alignment.invalidate_alignment_record(
            heightmap_dir_path,
            reason,
            printf=printf,
        )
    except Exception as exc:
        printf("Warning: could not invalidate OSM alignment mask record: " + str(exc))
        invalidated = False

    if invalidated:
        last_alignment_heightmap_dir = str(heightmap_dir_path)
        refreshOSMMaskAlignmentStatus(
            options_entries_dict,
            heightmap_dir_path,
            printf=printf,
        )
    return invalidated


def _markOSMMaskCurrentAfterRebuild(
    heightmap_dir_path,
    result=None,
    printf=None,
):
    """Update the UI cheaply after a verified rebuild without reloading files."""
    global last_alignment_heightmap_dir
    last_alignment_heightmap_dir = str(heightmap_dir_path)
    _setOSMMaskStatus(
        "OSM alignment mask: CURRENT - manual mask edits are preserved",
        "#006400",
    )
    if printf is not None:
        try:
            action = result.get("action") if isinstance(result, dict) else "rebuilt"
            printf("OSM alignment mask status: current (" + str(action) + ")")
        except Exception:
            pass


def rebuildOSMMaskFromCurrentAlignment(
    options_entries_dict,
    printf,
    heightmap_dir_path=None,
    force=True,
    confirm_replace=False,
    osm_file_override=None,
    ew_override=None,
    ns_override=None,
    progress_callback=None,
    printf_override=None,
):
    """Synchronous engine retained for tests/controlled callers.

    Interactive buttons use the asynchronous wrapper below so neither Tk
    window is blocked while the full-resolution mask is generated.
    """
    global root
    global last_alignment_heightmap_dir

    try:
        values = _currentOSMMaskInputs(
            options_entries_dict,
            osm_file_override=osm_file_override,
            ew_override=ew_override,
            ns_override=ns_override,
        )
    except Exception as exc:
        alert(str(exc))
        return False

    if not values["use_osm"]:
        alert("Enable Import OpenStreetMap before rebuilding the alignment mask.")
        return False
    if not values["local_osm_file"]:
        alert("Select a Local OSM File before rebuilding the alignment mask.")
        return False

    folder = str(heightmap_dir_path or last_alignment_heightmap_dir or "").strip()
    if not folder:
        folder = tk.filedialog.askdirectory(
            initialdir=(root.filename if root and hasattr(root, "filename") else "."),
            title="Select heightmap folder for aligned mask rebuild",
        )
    if not folder:
        return False

    last_alignment_heightmap_dir = folder
    log = printf_override or printf

    if not force:
        status = osm_mask_alignment.get_alignment_status(
            folder,
            values["local_osm_file"],
            values["adjust_ew"],
            values["adjust_ns"],
            values["auto_red_mask_enabled"],
            values["auto_red_mask_buffer_m"],
            include_vehicle_roads=values["include_vehicle_roads"],
            custom_unmatched_osm=values["custom_unmatched_osm"],
        )
        if status.get("state") == "current":
            result = {
                "action": "already_current",
                "message": (
                    "mask.png already matches this CFS alignment. "
                    "Existing manual mask edits were preserved."
                ),
            }
            _markOSMMaskCurrentAfterRebuild(folder, result, printf=printf)
            return result

    mask_path = Path(folder) / "mask.png"
    if confirm_replace and mask_path.is_file():
        proceed = messagebox.askyesno(
            "Rebuild Aligned Mask",
            "Rebuilding will replace mask.png using the current CFS alignment "
            "and Auto Red Mask settings. The existing mask will be backed up "
            "first. Continue?",
            parent=root,
        )
        if not proceed:
            return False

    try:
        result = osm_mask_alignment.rebuild_aligned_mask(
            folder,
            values["local_osm_file"],
            values["adjust_ew"],
            values["adjust_ns"],
            auto_red_mask_enabled=values["auto_red_mask_enabled"],
            auto_red_mask_buffer_m=values["auto_red_mask_buffer_m"],
            include_vehicle_roads=values["include_vehicle_roads"],
            custom_unmatched_osm=values["custom_unmatched_osm"],
            backup_existing=True,
            printf=log,
            progress_callback=progress_callback,
        )
    except Exception as exc:
        log("Aligned mask rebuild failed: " + str(exc))
        messagebox.showerror(
            "Aligned Mask Rebuild",
            "Could not rebuild mask.png from the current OSM alignment.\n\n" + str(exc),
            parent=root,
        )
        return False

    _markOSMMaskCurrentAfterRebuild(folder, result, printf=printf)
    return result


def _startOSMMaskRebuildProgressTask(
    job,
    printf,
    on_complete=None,
    success_title="Aligned Mask Rebuilt",
    show_success=True,
):
    """Run a full-resolution aligned-mask rebuild without blocking Tk."""
    global root
    global mask_rebuild_active

    if mask_rebuild_active:
        alert("An aligned-mask rebuild is already running. Please wait for it to finish.")
        return False

    mask_rebuild_active = True
    _setOSMMaskStatus(
        "OSM alignment mask: REBUILDING - the main window remains available",
        "#805500",
    )

    result_queue = queue.Queue()
    popup = tk.Toplevel(root)
    popup.title("Rebuilding Aligned OSM Mask")
    popup.geometry("720x175")
    popup.minsize(620, 165)
    popup.transient(root)

    Label(
        popup,
        text=(
            "Rebuilding mask.png from the final CFS alignment. "
            "Large heightmaps and OSM files may take several minutes."
        ),
        justify=LEFT,
        anchor="w",
        wraplength=680,
    ).pack(fill=X, padx=14, pady=(14, 8))

    progress_var = tk.DoubleVar(value=0.0)
    progress = ttk.Progressbar(
        popup,
        orient=HORIZONTAL,
        mode="determinate",
        maximum=100.0,
        variable=progress_var,
    )
    progress.pack(fill=X, padx=14, pady=4)

    status_var = tk.StringVar(value="Starting aligned-mask rebuild...")
    Label(
        popup,
        textvariable=status_var,
        justify=LEFT,
        anchor="w",
    ).pack(fill=X, padx=14, pady=(4, 12))

    def refuse_close():
        messagebox.showwarning(
            "Mask Rebuild In Progress",
            "The aligned mask is still being written and verified. "
            "Please wait for the operation to finish.",
            parent=popup,
        )

    popup.protocol("WM_DELETE_WINDOW", refuse_close)

    def worker_log(message):
        result_queue.put(("log", str(message)))

    def worker_progress(percent, message):
        result_queue.put(("progress", (float(percent), str(message))))

    def worker():
        try:
            worker_progress(2, "Checking current mask and alignment status...")
            if not bool(job.get("force", True)):
                status = osm_mask_alignment.get_alignment_status(
                    job["heightmap_dir"],
                    job["local_osm_file"],
                    job["adjust_ew"],
                    job["adjust_ns"],
                    job["auto_red_mask_enabled"],
                    job["auto_red_mask_buffer_m"],
                    include_vehicle_roads=job.get("include_vehicle_roads", False),
                    custom_unmatched_osm=job.get("custom_unmatched_osm", False),
                )
                if status.get("state") == "current":
                    worker_progress(100, "The aligned mask is already current.")
                    result_queue.put(("done", {
                        "action": "already_current",
                        "message": (
                            "mask.png already matches this CFS alignment. "
                            "Existing manual mask edits were preserved."
                        ),
                    }))
                    return

            result = osm_mask_alignment.rebuild_aligned_mask(
                job["heightmap_dir"],
                job["local_osm_file"],
                job["adjust_ew"],
                job["adjust_ns"],
                auto_red_mask_enabled=job["auto_red_mask_enabled"],
                auto_red_mask_buffer_m=job["auto_red_mask_buffer_m"],
                include_vehicle_roads=job.get("include_vehicle_roads", False),
                custom_unmatched_osm=job.get("custom_unmatched_osm", False),
                backup_existing=True,
                printf=worker_log,
                progress_callback=worker_progress,
            )
            result_queue.put(("done", result))
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def pump():
        global mask_rebuild_active
        finished = False
        while True:
            try:
                kind, payload = result_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "progress":
                percent, message = payload
                progress_var.set(max(0.0, min(100.0, float(percent))))
                status_var.set(str(message))
            elif kind == "log":
                try:
                    printf(payload)
                except Exception:
                    pass
            elif kind == "error":
                mask_rebuild_active = False
                finished = True
                _setOSMMaskStatus(
                    "OSM alignment mask: STALE - aligned-mask rebuild failed",
                    "#a00000",
                )
                try:
                    printf("Aligned mask rebuild failed:\n" + payload)
                except Exception:
                    pass
                popup.destroy()
                messagebox.showerror(
                    "Aligned Mask Rebuild",
                    "Could not rebuild mask.png from the current OSM alignment.\n\n"
                    + payload,
                    parent=root,
                )
            elif kind == "done":
                mask_rebuild_active = False
                finished = True
                _markOSMMaskCurrentAfterRebuild(
                    job["heightmap_dir"],
                    payload,
                    printf=printf,
                )
                popup.destroy()

                if on_complete is not None:
                    try:
                        on_complete(payload)
                    except Exception as exc:
                        printf("Warning: post-rebuild action failed: " + str(exc))

                if show_success:
                    backup = payload.get("backup_path") if isinstance(payload, dict) else None
                    detail = (
                        payload.get("message")
                        if isinstance(payload, dict)
                        else "mask.png was rebuilt from the current CFS alignment."
                    )
                    if backup:
                        detail += "\n\nPrevious mask backup:\n" + str(backup)
                    detail += (
                        "\n\nComplete any intended manual edits to mask.png before "
                        "importing terrain and OSM into the course."
                    )
                    messagebox.showinfo(success_title, detail, parent=root)

        if not finished and mask_rebuild_active:
            root.after(75, pump)

    threading.Thread(
        target=worker,
        name="TGC-Main-Aligned-Mask-Rebuild",
        daemon=True,
    ).start()
    root.after(75, pump)
    return True


def rebuildOSMMaskAction(options_entries_dict, printf):
    global root
    global last_alignment_heightmap_dir

    try:
        values = _currentOSMMaskInputs(options_entries_dict)
    except Exception as exc:
        alert(str(exc))
        return

    if not values["use_osm"]:
        alert("Enable Import OpenStreetMap before rebuilding the alignment mask.")
        return
    if not values["local_osm_file"]:
        alert("Select a Local OSM File before rebuilding the alignment mask.")
        return

    folder = str(last_alignment_heightmap_dir or "").strip()
    if not folder:
        folder = tk.filedialog.askdirectory(
            initialdir=(root.filename if root and hasattr(root, "filename") else "."),
            title="Select heightmap folder for aligned mask rebuild",
        )
    if not folder:
        return

    last_alignment_heightmap_dir = folder
    mask_path = Path(folder) / "mask.png"
    if mask_path.is_file():
        proceed = messagebox.askyesno(
            "Rebuild Aligned Mask",
            "Rebuilding will replace mask.png using the current CFS alignment "
            "and Auto Red Mask settings. The existing mask will be backed up "
            "first. Continue?",
            parent=root,
        )
        if not proceed:
            return

    job = {
        "heightmap_dir": folder,
        "local_osm_file": values["local_osm_file"],
        "adjust_ew": values["adjust_ew"],
        "adjust_ns": values["adjust_ns"],
        "auto_red_mask_enabled": values["auto_red_mask_enabled"],
        "auto_red_mask_buffer_m": values["auto_red_mask_buffer_m"],
        "include_vehicle_roads": values["include_vehicle_roads"],
        "custom_unmatched_osm": values["custom_unmatched_osm"],
        "force": True,
    }
    _startOSMMaskRebuildProgressTask(job, printf)

def validateOSMMaskBeforeCourseImport(
    options_entries_dict,
    heightmap_dir_path,
    printf,
):
    """Block shifted Local OSM imports until mask.png matches final CFS alignment."""
    global last_alignment_heightmap_dir
    global mask_rebuild_active
    last_alignment_heightmap_dir = str(heightmap_dir_path)

    if mask_rebuild_active:
        alert(
            "The aligned mask is still being rebuilt. Wait for it to finish "
            "before importing the heightmap and OSM into the course."
        )
        return False

    try:
        values = _currentOSMMaskInputs(options_entries_dict)
    except Exception as exc:
        alert(str(exc))
        return False

    if not values["use_osm"] or not values["local_osm_file"]:
        refreshOSMMaskAlignmentStatus(options_entries_dict, heightmap_dir_path)
        return True

    status = refreshOSMMaskAlignmentStatus(
        options_entries_dict,
        heightmap_dir_path,
        printf=printf,
    )
    if status.get("state") == "current":
        return True

    if status.get("state") == "legacy_zero_shift":
        choice = messagebox.askyesnocancel(
            "Existing Zero-Shift Mask",
            "This mask predates CFS alignment tracking and the current shift is "
            "0.00 m E/W and 0.00 m N/S.\n\n"
            "Choose Yes to rebuild the mask using the current OSM and Auto Red "
            "Mask settings. The existing mask will be backed up.\n\n"
            "Choose No to adopt the existing mask without changing any of its "
            "pixels, which preserves prior manual edits.\n\n"
            "Choose Cancel to stop the import.",
            parent=root,
        )
        if choice is None:
            return False
        if choice:
            job = {
                "heightmap_dir": str(heightmap_dir_path),
                "local_osm_file": values["local_osm_file"],
                "adjust_ew": values["adjust_ew"],
                "adjust_ns": values["adjust_ns"],
                "auto_red_mask_enabled": values["auto_red_mask_enabled"],
                "auto_red_mask_buffer_m": values["auto_red_mask_buffer_m"],
                "include_vehicle_roads": values["include_vehicle_roads"],
                "custom_unmatched_osm": values["custom_unmatched_osm"],
                "force": True,
            }

            def legacy_rebuild_complete(_result):
                messagebox.showinfo(
                    "Aligned Mask Ready",
                    "The aligned mask is ready. Complete any intended manual "
                    "edits to mask.png, then click Select and Import Heightmap "
                    "and OSM into Course again.",
                    parent=root,
                )

            _startOSMMaskRebuildProgressTask(
                job,
                printf,
                on_complete=legacy_rebuild_complete,
                show_success=False,
            )
            return False

        try:
            osm_mask_alignment.adopt_existing_zero_shift_mask(
                heightmap_dir_path,
                values["local_osm_file"],
                values["adjust_ew"],
                values["adjust_ns"],
                auto_red_mask_enabled=values["auto_red_mask_enabled"],
                auto_red_mask_buffer_m=values["auto_red_mask_buffer_m"],
                include_vehicle_roads=values["include_vehicle_roads"],
                custom_unmatched_osm=values["custom_unmatched_osm"],
                printf=printf,
            )
            refreshOSMMaskAlignmentStatus(
                options_entries_dict,
                heightmap_dir_path,
                printf=printf,
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                "Existing Mask Could Not Be Adopted",
                str(exc),
                parent=root,
            )
            return False

    messagebox.showerror(
        "OSM Alignment Mask Is Stale",
        "The selected mask does not match the current Local OSM alignment.\n\n"
        + str(status.get("message", "Rebuild required."))
        + "\n\nOpen the CFS Alignment Viewer and apply the final alignment, or use "
        "Rebuild Mask from Current Alignment. Then complete any intended "
        "manual edits to mask.png before importing.",
        parent=root,
    )
    return False


def runLidar(
    scale_entry,
    epsg_entry,
    printf,
    auto_red_mask_var=None,
    auto_red_mask_buffer_var=None,
    lidar_dir_path_override=None,
    ignore_force_epsg=False,
):
    """Run heavy LiDAR preparation and terrain rasterization off the Tk thread."""
    global root
    global lidar_processing_active

    if lidar_processing_active:
        alert("LiDAR processing is already running. Wait for it to finish first.")
        return

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before processing lidar files")
        return

    try:
        sample_scale = float(scale_entry.get())
    except Exception:
        alert("No action taken: Could not get valid resolution from entry")
        return

    force_epsg = None
    if not ignore_force_epsg:
        try:
            epsg_raw = epsg_entry.get()
            if epsg_raw:
                force_epsg = int(epsg_raw)
        except Exception:
            alert("No action taken: Could not get valid force epsg from entry")
            return

    auto_red_settings = getAutoRedMaskSettings(
        auto_red_mask_var,
        auto_red_mask_buffer_var,
    )
    if auto_red_settings is None:
        return
    auto_red_enabled, auto_red_buffer_m = auto_red_settings

    if lidar_dir_path_override:
        lidar_dir_path = str(lidar_dir_path_override)
        printf("Using LiDAR directory: " + lidar_dir_path)
    else:
        lidar_dir_path = tk.filedialog.askdirectory(
            initialdir=root.filename,
            title="Select las/laz files directory",
        )
        if not lidar_dir_path:
            return

    local_osm_file = ""
    try:
        for key, entry in options_entries_dict.items():
            try:
                value = entry.get()
            except Exception:
                continue
            if isinstance(value, str):
                candidate = value.strip()
                if candidate.lower().endswith((".osm", ".xml")):
                    local_osm_file = candidate
                    break
    except Exception:
        local_osm_file = ""

    custom_unmatched_osm = bool(
        _mask_option_value(options_entries_dict, "custom_unmatched_osm", False)
    )
    processing_local_osm_file = local_osm_file
    if local_osm_file and custom_unmatched_osm:
        processing_local_osm_file = ""
        printf(
            "Custom / Unmatched OSM enabled: LiDAR/DEM projection and crop are "
            "authoritative. The Local OSM geographic location will NOT control "
            "terrain processing. A detached copy will be centered on the terrain "
            "for the selection preview and then re-centered on the finished crop in CFS."
        )
    elif local_osm_file:
        printf("LiDAR will use local OSM for preview/mask: " + local_osm_file)
    else:
        printf("LiDAR local OSM is blank; using online Overpass for preview/mask")

    if auto_red_enabled:
        printf(
            "Auto Red Mask buffer: " +
            str(round(auto_red_buffer_m, 2)) + " m"
        )

    output_dir_path = root.filename
    result_queue = queue.Queue()
    lidar_processing_active = True

    printf(
        "LiDAR Fast job started in background. "
        "The window should remain responsive."
    )

    def worker_printf(message):
        result_queue.put(("log", str(message)))

    def prepare_worker():
        try:
            prepared = lidar_map_api.prepare_lidar_previews(
                lidar_dir_path,
                sample_scale,
                output_dir_path,
                force_epsg=force_epsg,
                printf=worker_printf,
                local_osm_file=processing_local_osm_file,
                auto_red_mask_enabled=auto_red_enabled,
                auto_red_mask_buffer_m=auto_red_buffer_m,
            )
            if prepared is not None and local_osm_file and custom_unmatched_osm:
                prepared = _apply_custom_unmatched_preview_overlay(
                    prepared,
                    local_osm_file,
                    "lidar",
                    auto_red_mask_enabled=auto_red_enabled,
                    auto_red_mask_buffer_m=auto_red_buffer_m,
                    printf=worker_printf,
                )
            result_queue.put(("preview", prepared))
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def height_worker(prepared, crop):
        try:
            lidar_map_api.generate_lidar_heightmap(
                prepared["pc"],
                prepared["img_points"],
                prepared["sample_scale"],
                prepared["output_dir_path"],
                prepared["osm_result"],
                prepared["auto_red_mask_enabled"],
                prepared["auto_red_mask_buffer_m"],
                crop_bounds=crop,
                printf=worker_printf,
                defer_mask_edit_message=bool(local_osm_file),
            )
            if local_osm_file and not custom_unmatched_osm:
                worker_printf(
                    "Local OSM selected: converting the LiDAR crop to the "
                    "OSM-defined master terrain extent."
                )
                lidar_map_api.reframe_heightmap_to_osm_master(
                    Path(prepared["output_dir_path"]) / "heightmap.npy",
                    local_osm_file,
                    buffer_m=AWS_EPT_OSM_BUFFER_M,
                    auto_red_mask_enabled=auto_red_enabled,
                    auto_red_mask_buffer_m=auto_red_buffer_m,
                    printf=worker_printf,
                )
                # TGC_OSM_MASTER_MASK_READY_MESSAGE_V1
                worker_printf(
                    "OSM master terrain and provisional mask are complete. "
                    "Next, use the CFS Alignment Viewer and apply the final "
                    "alignment to rebuild mask.png before making manual mask edits."
                )
            elif local_osm_file and custom_unmatched_osm:
                worker_printf(
                    "Custom / Unmatched terrain processing complete. The terrain "
                    "master grid was preserved independently of the OSM location. "
                    "Open CFS Alignment Viewer to center/fine-shift the layout and rebuild mask.png."
                )
            result_queue.put(("done", None))
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def pump_worker_messages():
        global lidar_processing_active
        finished = False

        while True:
            try:
                kind, payload = result_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "log":
                printf(payload)
                continue

            if kind == "error":
                lidar_processing_active = False
                printf("LiDAR processing failed:")
                printf(payload)
                alert(
                    "LiDAR processing failed. "
                    "See the Load OSM and Process LiDAR/DEM console for details."
                )
                finished = True
                break

            if kind == "preview":
                if payload is None:
                    lidar_processing_active = False
                    finished = True
                    break
                printf("LiDAR preparation complete. Opening course-boundary selection.")
                try:
                    crop = lidar_map_api.show_prepared_lidar_preview(
                        payload,
                        printf=printf,
                    )
                except Exception:
                    lidar_processing_active = False
                    printf("LiDAR preview/crop failed:")
                    printf(traceback.format_exc())
                    alert("LiDAR preview/crop failed. See the console for details.")
                    finished = True
                    break

                if crop is None:
                    lidar_processing_active = False
                    printf("LiDAR boundary selection cancelled.")
                    finished = True
                    break

                printf("Course boundary accepted. Generating LiDAR heightmap in background.")
                threading.Thread(
                    target=height_worker,
                    args=(payload, crop),
                    name="TGC-LiDAR-Height-Worker",
                    daemon=True,
                ).start()
                continue

            if kind == "done":
                lidar_processing_active = False
                invalidateOSMMaskAlignmentAfterProcessing(
                    output_dir_path,
                    "LiDAR processing regenerated the provisional terrain mask; "
                    "apply the final CFS alignment and rebuild mask.png.",
                    options_entries_dict,
                    printf,
                )
                printf("LiDAR Fast processing complete.")
                finished = True
                break

        if not finished and lidar_processing_active:
            root.after(100, pump_worker_messages)

    threading.Thread(
        target=prepare_worker,
        name="TGC-LiDAR-Prepare-Worker",
        daemon=True,
    ).start()
    root.after(100, pump_worker_messages)


def runLocalLidarTerrainGapFill(
    epsg_entry,
    printf,
    auto_red_mask_var=None,
    auto_red_mask_buffer_var=None,
):
    """Fill only missing terrain cells from a local fallback LAS/LAZ folder."""
    global root
    global lidar_processing_active

    if lidar_processing_active:
        alert(
            "LiDAR processing is already running. "
            "Wait for it to finish first."
        )
        return

    if not root or not hasattr(root, "filename"):
        alert("Select a course directory before terrain gap fill")
        return

    heightmap_path = Path(root.filename) / "heightmap.npy"
    if not heightmap_path.is_file():
        alert(
            "Terrain Gap Fill requires an existing heightmap.npy. "
            "Process the primary/newer LiDAR first."
        )
        return

    try:
        existing = np.load(
            str(heightmap_path),
            allow_pickle=True,
        ).item()
        elevation = np.asarray(existing.get("heightmap"))
        if elevation.size == 0:
            raise ValueError()
    except Exception:
        alert(
            "Could not read the existing heightmap.npy. "
            "Process the primary/newer terrain first."
        )
        return

    force_epsg = None
    try:
        epsg_raw = str(epsg_entry.get() or "").strip()
        if epsg_raw:
            force_epsg = int(epsg_raw)
    except Exception:
        alert(
            "Force LiDAR Horizontal EPSG must be blank or a valid integer EPSG code."
        )
        return

    local_osm_file = ""
    try:
        entry = options_entries_dict.get("local_osm_file")
        if entry is not None:
            local_osm_file = str(entry.get() or "").strip()
    except Exception:
        local_osm_file = ""

    if not local_osm_file:
        alert(
            "Terrain Gap Fill now uses the Local OSM course boundary as the "
            "master extent. Select a Local OSM File first."
        )
        return
    if bool(_mask_option_value(options_entries_dict, "custom_unmatched_osm", False)):
        alert(
            "Terrain Gap Fill currently requires a geographically matched Local OSM "
            "because it uses that OSM as the terrain master extent. Turn off "
            "Custom / Unmatched for this step, or use the already-processed terrain."
        )
        return

    auto_red_enabled = True
    auto_red_buffer_m = AUTO_RED_MASK_BUFFER_DEFAULT_M
    try:
        if auto_red_mask_var is not None:
            auto_red_enabled = bool(auto_red_mask_var.get())
        if auto_red_mask_buffer_var is not None:
            auto_red_buffer_m = float(auto_red_mask_buffer_var.get())
    except Exception:
        auto_red_enabled = True
        auto_red_buffer_m = AUTO_RED_MASK_BUFFER_DEFAULT_M

    lidar_dir_path = tk.filedialog.askdirectory(
        initialdir=root.filename,
        title="Select older/fallback LAS/LAZ directory for Terrain Gap Fill",
    )
    if not lidar_dir_path:
        return

    result_queue = queue.Queue()
    lidar_processing_active = True

    printf(
        "Local LiDAR Terrain Gap Fill started in background."
    )
    printf(
        "Primary terrain: " + str(heightmap_path)
    )
    printf(
        "Fallback LiDAR: " + str(lidar_dir_path)
    )
    printf(
        "RULE: valid primary terrain is authoritative and will not be overwritten."
    )
    if force_epsg is not None:
        printf(
            "Fallback Force LiDAR Horizontal EPSG: " +
            str(force_epsg)
        )

    def worker_printf(message):
        result_queue.put(("log", str(message)))

    def worker():
        try:
            result = lidar_map_api.fill_missing_terrain_from_lidar(
                lidar_dir_path,
                heightmap_path,
                force_epsg=force_epsg,
                source_metadata={
                    "source": "Local LAS/LAZ Terrain Gap Fill",
                    "directory": str(lidar_dir_path),
                },
                local_osm_file=local_osm_file,
                osm_master_buffer_m=AWS_EPT_OSM_BUFFER_M,
                auto_red_mask_enabled=auto_red_enabled,
                auto_red_mask_buffer_m=auto_red_buffer_m,
                printf=worker_printf,
            )
            result_queue.put(("done", result))
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def pump_worker_messages():
        global lidar_processing_active
        finished = False

        while True:
            try:
                kind, payload = result_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "log":
                printf(payload)
                continue

            if kind == "error":
                lidar_processing_active = False
                printf("Local LiDAR Terrain Gap Fill failed:")
                printf(payload)
                alert(
                    "Local LiDAR Terrain Gap Fill failed. "
                    "See the Load OSM and Process LiDAR/DEM console for details."
                )
                finished = True
                break

            if kind == "done":
                lidar_processing_active = False
                invalidateOSMMaskAlignmentAfterProcessing(
                    heightmap_path.parent,
                    "Terrain Gap Fill regenerated mask.png; apply the final CFS "
                    "alignment and rebuild the aligned mask.",
                    options_entries_dict,
                    printf,
                )
                printf(
                    "Terrain Gap Fill finished. Filled cells: " +
                    str(payload.get("filled_cells", 0))
                )
                finished = True
                break

        if not finished and lidar_processing_active:
            root.after(100, pump_worker_messages)

    threading.Thread(
        target=worker,
        name="TGC-Local-LiDAR-Terrain-Gap-Fill",
        daemon=True,
    ).start()
    root.after(100, pump_worker_messages)



def runLocalLidarTreesOnly(
    scale_entry,
    epsg_entry,
    printf,
):
    """Use local LAS/LAZ only for tree candidates while preserving DEM terrain."""
    global root
    global lidar_processing_active

    if lidar_processing_active:
        alert(
            "LiDAR processing is already running. "
            "Wait for it to finish first."
        )
        return

    if not root or not hasattr(root, "filename"):
        alert("Select a course directory before processing local LiDAR trees")
        return

    heightmap_path = Path(root.filename) / "heightmap.npy"
    if not heightmap_path.is_file():
        alert(
            "Local LAS/LAZ Trees Only requires an existing DEM-generated "
            "heightmap.npy in the selected course directory."
        )
        return

    try:
        heightmap_data = np.load(
            str(heightmap_path),
            allow_pickle=True,
        ).item()
        source_kind = str(
            heightmap_data.get("source", "") or ""
        )
    except Exception:
        alert(
            "Could not read the existing heightmap.npy. "
            "Process the DEM first, then try Trees Only again."
        )
        return

    if "DEM" not in source_kind.upper():
        alert(
            "Local LAS/LAZ Trees Only requires a DEM-generated heightmap.npy. "
            "Current terrain source is: " + (source_kind or "unknown")
        )
        return

    try:
        sample_scale = float(scale_entry.get())
        if sample_scale <= 0.0:
            raise ValueError()
    except Exception:
        alert("Map Scale must be a number greater than zero.")
        return

    force_epsg = None
    try:
        epsg_raw = str(epsg_entry.get() or "").strip()
        if epsg_raw:
            force_epsg = int(epsg_raw)
    except Exception:
        alert(
            "Force LiDAR Horizontal EPSG must be blank or a valid integer EPSG code."
        )
        return

    lidar_dir_path = tk.filedialog.askdirectory(
        initialdir=root.filename,
        title="Select local LAS/LAZ directory for Trees Only",
    )
    if not lidar_dir_path:
        return

    local_osm_file = ""
    try:
        entry = options_entries_dict.get("local_osm_file")
        if entry is not None:
            local_osm_file = str(entry.get() or "").strip()
    except Exception:
        local_osm_file = ""

    custom_unmatched_osm = bool(
        _mask_option_value(options_entries_dict, "custom_unmatched_osm", False)
    )
    tree_filter_osm_file = "" if custom_unmatched_osm else local_osm_file

    result_queue = queue.Queue()
    lidar_processing_active = True

    printf(
        "Local LAS/LAZ Trees Only started in background. "
        "Existing DEM terrain will be preserved."
    )
    printf("Local LiDAR directory: " + str(lidar_dir_path))
    if force_epsg is not None:
        printf(
            "Local tree-only Force LiDAR Horizontal EPSG: " +
            str(force_epsg)
        )
    else:
        printf(
            "Local tree-only LiDAR CRS: auto-detect from LAS/LAZ headers."
        )
    if tree_filter_osm_file:
        printf(
            "Local tree-only extraction will use Local OSM: " +
            tree_filter_osm_file
        )
    elif local_osm_file and custom_unmatched_osm:
        printf(
            "Custom / Unmatched OSM is not used to geographically clip Trees Only; "
            "the final imported golf features will still drive playing-surface tree filtering."
        )

    def worker_printf(message):
        result_queue.put(("log", str(message)))

    def worker():
        try:
            source_metadata = {
                "source": "Local LAS/LAZ Trees Only",
                "directory": str(lidar_dir_path),
                "force_epsg": force_epsg,
            }
            count = lidar_map_api.attach_lidar_trees_to_existing_dem(
                lidar_dir_path,
                heightmap_path,
                sample_scale=sample_scale,
                local_osm_file=(tree_filter_osm_file or None),
                force_epsg=force_epsg,
                source_metadata=source_metadata,
                printf=worker_printf,
            )
            result_queue.put(("done", count))
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def pump_worker_messages():
        global lidar_processing_active

        finished = False
        while True:
            try:
                kind, payload = result_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "log":
                printf(payload)
                continue

            if kind == "error":
                lidar_processing_active = False
                printf("Local LAS/LAZ Trees Only failed:")
                printf(payload)
                alert(
                    "Local LAS/LAZ Trees Only failed. "
                    "See the Load OSM and Process LiDAR/DEM console for details."
                )
                finished = True
                break

            if kind == "done":
                lidar_processing_active = False
                printf(
                    "Local LAS/LAZ Trees Only complete: " +
                    str(payload) + " LiDAR tree candidate(s) attached."
                )
                printf(
                    "DEM terrain remains unchanged. "
                    "Use Import Terrain and Features normally with "
                    "Add Trees From Lidar enabled."
                )
                finished = True
                break

        if not finished and lidar_processing_active:
            root.after(100, pump_worker_messages)

    threading.Thread(
        target=worker,
        name="TGC-Local-LiDAR-Trees-Only",
        daemon=True,
    ).start()
    root.after(100, pump_worker_messages)



def _terrain_gap_fill_ready():
    global root
    if not root or not hasattr(root, "filename"):
        return False
    path = Path(root.filename) / "heightmap.npy"
    if not path.is_file():
        return False
    try:
        data = np.load(str(path), allow_pickle=True).item()
        heightmap = np.asarray(data.get("heightmap"))
        return heightmap.size > 0
    except Exception:
        return False


def _aws_ept_dem_ready():
    global root
    if not root or not hasattr(root, "filename"):
        return False
    path = Path(root.filename) / "heightmap.npy"
    if not path.is_file():
        return False
    try:
        data = np.load(str(path), allow_pickle=True).item()
        return "DEM" in str(data.get("source", "") or "").upper()
    except Exception:
        return False


def showAwsEptDatasetChooser(candidates):
    """Modal USGS acquisition chooser with fixed actions and clear selection."""
    # TGC_AWS_EPT_CHOOSER_BUTTONS_ALWAYS_VISIBLE_V1
    # TGC_AWS_EPT_CHOOSER_BLUE_SELECTION_V1
    result = {"candidate": None, "mode": None}
    popup = tk.Toplevel(root)
    popup.title("Choose USGS LiDAR Acquisition")
    popup.transient(root)
    popup.grab_set()
    popup.resizable(True, True)

    # Fit inside the current display instead of assuming that 1500x680 fits
    # after Windows DPI scaling and title/task bars are accounted for.
    popup.update_idletasks()
    screen_width = max(640, int(popup.winfo_screenwidth()))
    screen_height = max(520, int(popup.winfo_screenheight()))
    window_width = min(1500, max(720, screen_width - 80))
    window_height = min(820, max(560, screen_height - 120))
    window_width = min(window_width, screen_width)
    window_height = min(window_height, screen_height)
    window_x = max(0, int((screen_width - window_width) / 2))
    window_y = max(0, int((screen_height - window_height) / 3))
    popup.geometry(
        str(window_width) + "x" + str(window_height) +
        "+" + str(window_x) + "+" + str(window_y)
    )
    popup.minsize(
        min(900, window_width),
        min(520, window_height),
    )

    # Only the dataset table expands. The details, status, and action rows are
    # fixed below it, so the buttons cannot be pushed off the bottom edge.
    popup.grid_columnconfigure(0, weight=1)
    popup.grid_rowconfigure(1, weight=1, minsize=120)

    intro = (
        "Choose the LiDAR acquisition you want. Collection dates are the actual "
        "flight/acquisition dates when WESM provides them; publication date is "
        "shown separately in the details. Public AWS EPT availability is also "
        "checked before you choose."
    )
    Label(
        popup,
        text=intro,
        justify=LEFT,
        anchor="w",
        wraplength=max(600, window_width - 50),
    ).grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 6))

    columns = (
        "year",
        "collection",
        "ql",
        "lidar_resolution",
        "dem_gsd",
        "lpc_status",
        "aws",
        "project",
    )
    table_frame = Frame(popup)
    table_frame.grid(row=1, column=0, sticky="nsew", padx=10)
    table_frame.grid_rowconfigure(0, weight=1)
    table_frame.grid_columnconfigure(0, weight=1)

    # Use a dedicated style rather than relying on the active Windows ttk
    # theme, because some themes make the selected row nearly indistinguishable
    # after the detail pane or an action button receives focus.  The selected
    # acquisition remains standard Windows blue with white text.
    aws_ept_tree_style_name = "TgcAwsEpt.Treeview"
    aws_ept_tree_style = ttk.Style(popup)
    try:
        aws_ept_tree_style.configure(aws_ept_tree_style_name)
        aws_ept_tree_style.map(
            aws_ept_tree_style_name,
            background=[("selected", "#0078D7")],
            foreground=[("selected", "#FFFFFF")],
        )
    except tk.TclError:
        aws_ept_tree_style_name = "Treeview"

    tree = ttk.Treeview(
        table_frame,
        style=aws_ept_tree_style_name,
        columns=columns,
        show="headings",
        selectmode="browse",
        height=10,
    )
    headings = {
        "year": "Year",
        "collection": "Collection dates",
        "ql": "3DEP quality",
        "lidar_resolution": "QL pulse spacing / density",
        "dem_gsd": "Source DEM GSD",
        "lpc_status": "LPC status",
        "aws": "Public AWS EPT",
        "project": "USGS project",
    }
    widths = {
        "year": 70,
        "collection": 190,
        "ql": 110,
        "lidar_resolution": 300,
        "dem_gsd": 130,
        "lpc_status": 155,
        "aws": 130,
        "project": 340,
    }
    for column in columns:
        tree.heading(column, text=headings[column])
        tree.column(
            column,
            width=widths[column],
            minwidth=60,
            stretch=(column == "project"),
        )

    yscroll = ttk.Scrollbar(
        table_frame,
        orient=VERTICAL,
        command=tree.yview,
    )
    xscroll = ttk.Scrollbar(
        table_frame,
        orient=HORIZONTAL,
        command=tree.xview,
    )
    tree.configure(
        yscrollcommand=yscroll.set,
        xscrollcommand=xscroll.set,
    )
    tree.grid(row=0, column=0, sticky="nsew")
    yscroll.grid(row=0, column=1, sticky="ns")
    xscroll.grid(row=1, column=0, sticky="ew")

    # Tag coloring is a fallback for themes that override ttk state maps.
    # It also keeps the chosen acquisition blue when focus moves to details or
    # to one of the action buttons.
    tree.tag_configure(
        "aws_ept_selected",
        background="#0078D7",
        foreground="#FFFFFF",
    )

    iid_to_candidate = {}
    for index, candidate in enumerate(candidates):
        start_date = str(candidate.get("collect_start") or "")
        end_date = str(candidate.get("collect_end") or "")
        if start_date and end_date:
            collection = (
                start_date if start_date == end_date
                else start_date + " to " + end_date
            )
        else:
            collection = start_date or end_date or "Unknown"

        aws_text = (
            "Available"
            if candidate.get("ept_available")
            else "Not available"
        )
        iid = "dataset_" + str(index)
        iid_to_candidate[iid] = candidate
        tree.insert(
            "",
            END,
            iid=iid,
            values=(
                candidate.get("collection_year") or "",
                collection,
                candidate.get("ql") or "Unknown",
                candidate.get("ql_reference") or "Not listed",
                candidate.get("dem_gsd") or "Not listed",
                candidate.get("lpc_category") or "Not listed",
                aws_text,
                candidate.get("project") or "",
            ),
        )

    details_frame = ttk.LabelFrame(
        popup,
        text="Selected acquisition details",
    )
    details_frame.grid(
        row=2,
        column=0,
        sticky="ew",
        padx=10,
        pady=(8, 4),
    )
    details_frame.grid_columnconfigure(0, weight=1)
    details_text = ScrolledText(
        details_frame,
        height=7,
        wrap=WORD,
        relief=FLAT,
        padx=6,
        pady=4,
    )
    details_text.grid(row=0, column=0, sticky="ew")
    details_text.configure(state=DISABLED)

    def set_details(text):
        details_text.configure(state=NORMAL)
        details_text.delete("1.0", END)
        details_text.insert("1.0", str(text))
        details_text.configure(state=DISABLED)

    dem_ready = _aws_ept_dem_ready()
    gap_fill_ready = _terrain_gap_fill_ready()
    dem_note = (
        "Trees Only is available: current heightmap source is DEM."
        if dem_ready else
        "Trees Only requires a DEM-generated heightmap.npy in the selected course directory."
    )
    if gap_fill_ready:
        dem_note += "  Terrain Gap Fill is available for the current heightmap."
    dem_note_var = tk.StringVar(value=dem_note)
    Label(
        popup,
        textvariable=dem_note_var,
        justify=LEFT,
        anchor="w",
        wraplength=max(600, window_width - 50),
    ).grid(row=3, column=0, sticky="ew", padx=10, pady=(0, 6))

    button_frame = Frame(popup)
    button_frame.grid(row=4, column=0, sticky="ew", padx=10, pady=(0, 10))

    terrain_button = ttk.Button(
        button_frame,
        text="Use for Terrain + Trees",
    )
    tree_button = ttk.Button(
        button_frame,
        text="Use for Trees Only (Keep DEM Terrain)",
    )
    gap_fill_button = ttk.Button(
        button_frame,
        text="Use as Terrain Gap Fill (Keep Primary Terrain)",
    )
    cancel_button = ttk.Button(
        button_frame,
        text="Cancel",
    )
    action_buttons = (
        terrain_button,
        tree_button,
        gap_fill_button,
        cancel_button,
    )

    # Keep the actions readable on narrower displays by switching to a 2x2
    # footer instead of forcing four long labels into one row.
    button_columns = 4 if window_width >= 1220 else 2
    for column in range(button_columns):
        button_frame.grid_columnconfigure(column, weight=1)
    for index, button in enumerate(action_buttons):
        row = index // button_columns
        column = index % button_columns
        button.grid(
            row=row,
            column=column,
            sticky="ew",
            padx=6,
            pady=3,
        )

    if not dem_ready:
        tree_button.configure(state=DISABLED)
    if not gap_fill_ready:
        gap_fill_button.configure(state=DISABLED)

    def refresh_selected_row_highlight(_event=None):
        selection = set(tree.selection())
        for iid in tree.get_children(""):
            current = tuple(
                tag for tag in tree.item(iid, "tags")
                if tag != "aws_ept_selected"
            )
            if iid in selection:
                current = current + ("aws_ept_selected",)
            tree.item(iid, tags=current)

    def selected_candidate():
        selection = tree.selection()
        if not selection:
            return None
        return iid_to_candidate.get(selection[0])

    def update_details(_event=None):
        refresh_selected_row_highlight()
        candidate = selected_candidate()
        if candidate is None:
            set_details("Select a dataset to see full metadata.")
            terrain_button.configure(state=DISABLED)
            tree_button.configure(state=DISABLED)
            gap_fill_button.configure(state=DISABLED)
            return

        available = bool(candidate.get("ept_available"))
        terrain_button.configure(
            state=NORMAL if available else DISABLED
        )
        tree_button.configure(
            state=NORMAL if (available and dem_ready) else DISABLED
        )
        gap_fill_button.configure(
            state=NORMAL if (available and gap_fill_ready) else DISABLED
        )

        lines = [
            "Project: " + str(candidate.get("project") or ""),
            "Work units: " + ", ".join(candidate.get("workunits") or []),
            "Collection: " +
            str(candidate.get("collect_start") or "?") + " to " +
            str(candidate.get("collect_end") or "?"),
            "3DEP QL: " + str(candidate.get("ql") or "Not listed"),
            "QL reference: " +
            str(candidate.get("ql_reference") or "Not listed"),
            "Specification: " +
            str(candidate.get("spec") or "Not listed"),
            "Production method: " +
            str(candidate.get("production_method") or "Not listed"),
            "Source DEM GSD: " +
            str(candidate.get("dem_gsd") or "Not listed"),
            "LPC publication date: " +
            str(candidate.get("lpc_pub_date") or "Not listed"),
            "LPC status: " +
            str(candidate.get("lpc_category") or "Not listed"),
            "Horizontal CRS: " +
            str(candidate.get("horizontal_crs") or "Not listed"),
            "Vertical CRS: " +
            str(candidate.get("vertical_crs") or "Not listed"),
            "Geoid: " + str(candidate.get("geoid") or "Not listed"),
            "AWS EPT: " + str(candidate.get("ept_note") or ""),
        ]
        if candidate.get("lpc_reason"):
            lines.append(
                "LPC variance/reason: " +
                str(candidate.get("lpc_reason"))
            )
        set_details("\n".join(lines))

    def choose(mode):
        candidate = selected_candidate()
        if candidate is None:
            return
        if not candidate.get("ept_available"):
            return
        if mode == "trees" and not dem_ready:
            return
        if mode == "gap_fill" and not gap_fill_ready:
            return
        result["candidate"] = candidate
        result["mode"] = mode
        popup.destroy()

    terrain_button.configure(
        command=lambda: choose("full"),
        state=DISABLED,
    )
    tree_button.configure(
        command=lambda: choose("trees"),
        state=DISABLED,
    )
    gap_fill_button.configure(
        command=lambda: choose("gap_fill"),
        state=DISABLED,
    )
    cancel_button.configure(command=popup.destroy)
    tree.bind("<<TreeviewSelect>>", update_details)
    tree.bind(
        "<FocusOut>",
        refresh_selected_row_highlight,
        add="+",
    )
    popup.bind("<Escape>", lambda _event: popup.destroy())

    if candidates:
        first = "dataset_0"
        tree.selection_set(first)
        tree.focus(first)
        tree.see(first)
        update_details()
        tree.focus_set()
    else:
        set_details("No LiDAR acquisitions were returned for this extent.")

    popup.protocol("WM_DELETE_WINDOW", popup.destroy)
    popup.update_idletasks()
    popup.lift()
    popup.wait_window()
    return result["candidate"], result["mode"]


def runAwsEptLidar(
    scale_entry,
    epsg_entry,
    printf,
    auto_red_mask_var=None,
    auto_red_mask_buffer_var=None,
):
    """Discover, choose and download public USGS AWS EPT using Local OSM."""
    global root
    global lidar_processing_active

    if lidar_processing_active:
        alert(
            "LiDAR processing is already running. "
            "Wait for it to finish first."
        )
        return

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before downloading AWS EPT LiDAR")
        return

    local_osm_file = ""
    try:
        entry = options_entries_dict.get("local_osm_file")
        if entry is not None:
            local_osm_file = str(entry.get() or "").strip()
    except Exception:
        local_osm_file = ""

    if not local_osm_file:
        alert(
            "Select a Local OSM File at the top of the Load OSM and "
            "Process LiDAR/DEM tab before using USGS AWS EPT."
        )
        return
    if bool(_mask_option_value(options_entries_dict, "custom_unmatched_osm", False)):
        alert(
            "USGS AWS EPT discovery uses the Local OSM's real-world location to "
            "choose/download LiDAR. Custom / Unmatched intentionally ignores that "
            "location, so AWS discovery is disabled in this mode. Use local LiDAR/DEM "
            "for the target terrain, or turn Custom / Unmatched off for discovery."
        )
        return

    try:
        sample_scale = float(scale_entry.get())
        if sample_scale <= 0.0:
            raise ValueError()
    except Exception:
        alert("Map Scale must be a number greater than zero.")
        return

    result_queue = queue.Queue()
    lidar_processing_active = True

    printf(
        "USGS AWS EPT dataset discovery started in background. "
        "Local OSM extent buffer=" +
        str(int(AWS_EPT_OSM_BUFFER_M)) + " m."
    )
    printf(
        "USGS WESM metadata will be used for acquisition dates, quality, "
        "specification and source DEM resolution."
    )

    def worker_printf(message):
        result_queue.put(("log", str(message)))

    def discovery_worker():
        try:
            bbox, candidates = (
                usgs_ept_downloader.discover_osm_ept_candidates(
                    local_osm_file,
                    root.filename,
                    buffer_m=AWS_EPT_OSM_BUFFER_M,
                    printf=worker_printf,
                )
            )
            result_queue.put(
                ("candidates", (bbox, candidates))
            )
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def selected_download_worker(bbox, candidate, mode):
        try:
            lidar_dir_path = (
                usgs_ept_downloader.download_candidate_ept_laz(
                    candidate,
                    bbox,
                    root.filename,
                    osm_file=local_osm_file,
                    buffer_m=AWS_EPT_OSM_BUFFER_M,
                    printf=worker_printf,
                )
            )

            if mode == "trees":
                count = (
                    lidar_map_api.attach_lidar_trees_to_existing_dem(
                        lidar_dir_path,
                        Path(root.filename) / "heightmap.npy",
                        sample_scale=sample_scale,
                        local_osm_file=local_osm_file,
                        source_metadata=candidate,
                        printf=worker_printf,
                    )
                )
                result_queue.put(("trees_done", count))
            elif mode == "gap_fill":
                gap_result = (
                    lidar_map_api.fill_missing_terrain_from_lidar(
                        lidar_dir_path,
                        Path(root.filename) / "heightmap.npy",
                        force_epsg=None,
                        source_metadata=candidate,
                        local_osm_file=local_osm_file,
                        osm_master_buffer_m=AWS_EPT_OSM_BUFFER_M,
                        auto_red_mask_enabled=(
                            bool(auto_red_mask_var.get())
                            if auto_red_mask_var is not None else True
                        ),
                        auto_red_mask_buffer_m=(
                            float(auto_red_mask_buffer_var.get())
                            if auto_red_mask_buffer_var is not None
                            else AUTO_RED_MASK_BUFFER_DEFAULT_M
                        ),
                        printf=worker_printf,
                    )
                )
                result_queue.put(("gap_fill_done", gap_result))
            else:
                result_queue.put(
                    ("download_done", lidar_dir_path)
                )
        except Exception:
            result_queue.put(("error", traceback.format_exc()))

    def pump_worker_messages():
        global lidar_processing_active

        finished = False
        while True:
            try:
                kind, payload = result_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "log":
                printf(payload)
                continue

            if kind == "error":
                lidar_processing_active = False
                printf("USGS AWS EPT operation failed:")
                printf(payload)
                alert(
                    "USGS AWS EPT operation failed. "
                    "See the Load OSM and Process LiDAR/DEM console for details."
                )
                finished = True
                break

            if kind == "candidates":
                bbox, candidates = payload
                printf(
                    "Dataset discovery complete. Opening acquisition chooser."
                )
                candidate, mode = showAwsEptDatasetChooser(candidates)

                if candidate is None or mode is None:
                    lidar_processing_active = False
                    printf("USGS AWS EPT selection cancelled.")
                    finished = True
                    break

                printf(
                    "Selected LiDAR acquisition: " +
                    str(candidate.get("project") or "")
                )
                if candidate.get("collect_start") or candidate.get("collect_end"):
                    printf(
                        "Collection dates: " +
                        str(candidate.get("collect_start") or "?") +
                        " to " +
                        str(candidate.get("collect_end") or "?")
                    )
                printf(
                    "Selected use: " +
                    (
                        (
                            "Trees Only - preserve current DEM terrain"
                            if mode == "trees"
                            else (
                                "Terrain Gap Fill - preserve valid primary terrain"
                                if mode == "gap_fill"
                                else "Terrain + Trees"
                            )
                        )
                    )
                )

                threading.Thread(
                    target=selected_download_worker,
                    args=(bbox, candidate, mode),
                    name="TGC-USGS-EPT-Selected-Download",
                    daemon=True,
                ).start()
                continue

            if kind == "gap_fill_done":
                lidar_processing_active = False
                invalidateOSMMaskAlignmentAfterProcessing(
                    Path(root.filename),
                    "AWS EPT Terrain Gap Fill regenerated mask.png; apply the final "
                    "CFS alignment and rebuild the aligned mask.",
                    options_entries_dict,
                    printf,
                )
                printf(
                    "AWS EPT Terrain Gap Fill complete: filled " +
                    str(payload.get("filled_cells", 0)) +
                    " missing terrain cell(s)."
                )
                finished = True
                break

            if kind == "trees_done":
                lidar_processing_active = False
                printf(
                    "LiDAR tree layer attached to DEM terrain: " +
                    str(payload) + " candidate(s)."
                )
                printf(
                    "The next Import Terrain and Features run can use "
                    "LiDAR Trees normally; terrain remains the DEM."
                )
                finished = True
                break

            if kind == "download_done":
                lidar_processing_active = False
                printf(
                    "Selected AWS EPT subset is ready. "
                    "Starting the normal Beta 5 LiDAR terrain/tree pipeline."
                )
                runLidar(
                    scale_entry,
                    epsg_entry,
                    printf,
                    auto_red_mask_var,
                    auto_red_mask_buffer_var,
                    lidar_dir_path_override=payload,
                    ignore_force_epsg=True,
                )
                finished = True
                break

        if not finished and lidar_processing_active:
            root.after(100, pump_worker_messages)

    threading.Thread(
        target=discovery_worker,
        name="TGC-USGS-EPT-Discovery-Worker",
        daemon=True,
    ).start()
    root.after(100, pump_worker_messages)


def runDEM(scale_entry, printf, auto_red_mask_var=None, auto_red_mask_buffer_var=None):
    """Run DEM preparation/finalization on worker threads so Tk stays responsive."""
    global root
    global dem_processing_active

    if dem_processing_active:
        alert(
            "DEM processing is already running. "
            "Wait for it to finish before starting another DEM job."
        )
        return

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before processing DEM files")
        return

    try:
        dem_sample_scale = float(scale_entry.get())
        if dem_sample_scale <= 0.0:
            raise ValueError("Map Scale must be greater than zero")
    except Exception:
        alert("No action taken: Could not get valid DEM Map Scale")
        return

    auto_red_settings = getAutoRedMaskSettings(
        auto_red_mask_var,
        auto_red_mask_buffer_var,
    )
    if auto_red_settings is None:
        return
    auto_red_enabled, auto_red_buffer_m = auto_red_settings

    printf("Requested DEM output Map Scale: " + str(dem_sample_scale) + " meters")
    if auto_red_enabled:
        printf(
            "Auto Red Mask buffer: " +
            str(round(auto_red_buffer_m, 2)) + " m"
        )

    dem_files = tk.filedialog.askopenfilenames(
        initialdir=root.filename,
        title="Select one or more georeferenced DEM GeoTIFF files",
        filetypes=[
            ("GeoTIFF DEM Files", "*.tif *.tiff"),
            ("TIFF Files", "*.tif *.tiff"),
            ("All files", "*"),
        ]
    )
    if not dem_files:
        return

    local_osm_file = ""
    try:
        for key, entry in options_entries_dict.items():
            try:
                value = entry.get()
            except Exception:
                continue
            if isinstance(value, str):
                candidate = value.strip()
                if candidate.lower().endswith((".osm", ".xml")):
                    local_osm_file = candidate
                    break
    except Exception:
        local_osm_file = ""

    custom_unmatched_osm = bool(
        _mask_option_value(options_entries_dict, "custom_unmatched_osm", False)
    )
    processing_local_osm_file = local_osm_file
    if local_osm_file and custom_unmatched_osm:
        processing_local_osm_file = ""
        printf(
            "Custom / Unmatched OSM enabled: DEM CRS and selected terrain extent "
            "remain authoritative. Detached OSM geometry is centered for the DEM "
            "selection preview and then re-centered on the finished crop in CFS."
        )
    elif local_osm_file:
        printf("DEM will use local OSM for preview/mask: " + local_osm_file)
    else:
        printf("DEM local OSM is blank; online Overpass will be used for preview/mask")

    output_dir_path = root.filename
    selected_files = list(dem_files)

    result_queue = queue.Queue()
    dem_processing_active = True

    printf(
        "DEM job started in background: " +
        str(len(selected_files)) + " tile(s). "
        "The window should remain responsive."
    )

    def worker_printf(message):
        result_queue.put(("log", str(message)))

    def prepare_worker():
        try:
            prepared = dem_map_api.prepare_dem_previews(
                selected_files,
                local_osm_file=processing_local_osm_file,
                sample_scale=dem_sample_scale,
                auto_red_mask_enabled=auto_red_enabled,
                auto_red_mask_buffer_m=auto_red_buffer_m,
                printf=worker_printf,
            )
            if prepared is not None and local_osm_file and custom_unmatched_osm:
                prepared = _apply_custom_unmatched_preview_overlay(
                    prepared,
                    local_osm_file,
                    "dem",
                    auto_red_mask_enabled=auto_red_enabled,
                    auto_red_mask_buffer_m=auto_red_buffer_m,
                    printf=worker_printf,
                )
            result_queue.put(("prepared", prepared))
        except Exception:
            result_queue.put(
                ("error", traceback.format_exc())
            )

    def final_worker(prepared, crop):
        try:
            dem_map_api.generate_dem_output(
                prepared,
                output_dir_path,
                crop,
                auto_red_mask_enabled=auto_red_enabled,
                auto_red_mask_buffer_m=auto_red_buffer_m,
                printf=worker_printf,
            )
            result_queue.put(("final_done", None))
        except Exception:
            result_queue.put(
                ("error", traceback.format_exc())
            )

    def pump_worker_messages():
        global dem_processing_active

        finished = False
        waiting_for_final = False

        while True:
            try:
                kind, payload = result_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "log":
                printf(payload)
                continue

            if kind == "error":
                dem_processing_active = False
                printf("DEM processing failed:")
                printf(payload)
                alert(
                    "DEM processing failed. "
                    "See the Load OSM and Process LiDAR/DEM console for details."
                )
                finished = True
                break

            if kind == "prepared":
                printf(
                    "DEM preview preparation complete. "
                    "Opening course-boundary selection."
                )
                try:
                    crop = dem_map_api.show_prepared_dem_preview(
                        payload,
                        output_dir_path,
                        auto_red_mask_enabled=auto_red_enabled,
                        auto_red_mask_buffer_m=auto_red_buffer_m,
                        printf=printf,
                    )
                except Exception:
                    dem_processing_active = False
                    printf("DEM preview/crop failed:")
                    printf(traceback.format_exc())
                    alert(
                        "DEM preview/crop failed. "
                        "See the console for details."
                    )
                    finished = True
                    break

                if crop is None:
                    dem_processing_active = False
                    printf("DEM boundary selection cancelled.")
                    finished = True
                    break

                printf(
                    "Course boundary accepted. "
                    "Generating final DEM heightmap/mask in background."
                )
                threading.Thread(
                    target=final_worker,
                    args=(payload, crop),
                    name="TGC-DEM-Finalize-Worker",
                    daemon=True,
                ).start()
                waiting_for_final = True
                break

            if kind == "final_done":
                dem_processing_active = False
                invalidateOSMMaskAlignmentAfterProcessing(
                    output_dir_path,
                    "DEM processing regenerated the provisional terrain mask; "
                    "apply the final CFS alignment and rebuild mask.png.",
                    options_entries_dict,
                    printf,
                )
                if local_osm_file:
                    printf(
                        "DEM processing complete. The Local OSM mask is provisional "
                        "until the final CFS alignment is applied."
                    )
                else:
                    printf("DEM processing complete.")
                finished = True
                break

        if not finished and dem_processing_active:
            root.after(100, pump_worker_messages)

    threading.Thread(
        target=prepare_worker,
        name="TGC-DEM-Prepare-Worker",
        daemon=True,
    ).start()

    root.after(100, pump_worker_messages)

def generateCourseFromLidar(options_entries_dict, printf):
    global root
    global course_json
    global course_version
    global brush_scale_combo
    global last_alignment_heightmap_dir

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before processing heightmap file")
        return

    if course_json is None:
        alert("Make sure to import a .course file")
        return

    heightmap_dir_path = tk.filedialog.askdirectory(initialdir=root.filename, title="Select heightmap and mask files directory")
    if not heightmap_dir_path:
        return

    last_alignment_heightmap_dir = str(heightmap_dir_path)
    refreshOSMMaskAlignmentStatus(
        options_entries_dict,
        heightmap_dir_path,
    )

    allowed_scales = [1, 2, 3, 4, 6]
    detected_scale = None
    try:
        scale_info = np.load(heightmap_dir_path + '/heightmap.npy', allow_pickle=True).item()
        detected_scale = float(scale_info['image_scale'])
        allowed_scales = [v for v in allowed_scales if float(v) + 1e-6 >= detected_scale]

        if not allowed_scales:
            alert("The detected Lidar spacing is " + str(detected_scale) +
                  " m, which is larger than the largest configured 6 m brush size.")
            return

        if brush_scale_combo is not None:
            brush_scale_combo['values'] = tuple(str(v) for v in allowed_scales)

        current_scale = None
        try:
            current_scale = float(options_entries_dict["brush_scale"].get())
        except:
            pass

        if current_scale is None or current_scale + 1e-6 < detected_scale or current_scale not in [float(v) for v in allowed_scales]:
            new_scale = allowed_scales[0]
            options_entries_dict["brush_scale"].set(str(new_scale))
            printf("Detected Lidar spacing: " + str(detected_scale) +
                   " m. Brush sizes below the source spacing are locked out; using " +
                   str(new_scale) + " m.")
        else:
            printf("Detected Lidar spacing: " + str(detected_scale) +
                   " m. Allowed brush sizes: " +
                   ", ".join(str(v) + " m" for v in allowed_scales))
    except Exception as exc:
        printf("Warning: could not pre-read heightmap resolution for brush-size lockout: " + str(exc))

    options_dict = {}
    for key, entry in options_entries_dict.items():
        options_dict[key] = entry.get()

    if not validateOSMMaskBeforeCourseImport(
        options_entries_dict,
        heightmap_dir_path,
        printf,
    ):
        printf("Course import stopped: OSM alignment mask is not current.")
        return

    drawPlaceholder()
    course_json = tgc_image_terrain.generate_course(course_json, heightmap_dir_path, options_dict=options_dict,
            printf=printf, course_version=course_version)
    if course_json is not None:
        drawCourse(course_json)
        printf("Done Rendering Course Preview")
    else:
        printf("failed to generate course")
        print(course_version)

osm_types = [
    ('Open Street Map Exports', '*.osm'), 
    ('All files', '*'), 
]

def openCFSAlignmentViewer(options_entries_dict, printf):
    global root
    global last_alignment_heightmap_dir

    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory first")
        return

    try:
        mask_values = _currentOSMMaskInputs(options_entries_dict)
    except Exception as exc:
        alert(str(exc))
        return

    local_osm_file = str(mask_values["local_osm_file"] or "").strip()
    if not local_osm_file:
        alert("Select a Local OSM File before opening the alignment viewer")
        return

    heightmap_dir_path = tk.filedialog.askdirectory(
        initialdir=(last_alignment_heightmap_dir or root.filename),
        title="Select heightmap folder for CFS alignment verification"
    )
    if not heightmap_dir_path:
        return

    last_alignment_heightmap_dir = str(heightmap_dir_path)
    _setOSMMaskStatus(
        "OSM alignment mask: CFS viewer open - apply alignment to rebuild",
        "#805500",
    )

    # Capture non-alignment settings on the Tk thread. The worker callback below
    # touches no Tk objects and sends progress/log messages through the viewer.
    auto_red_enabled = bool(mask_values["auto_red_mask_enabled"])
    auto_red_buffer = float(mask_values["auto_red_mask_buffer_m"])
    include_vehicle_roads = bool(mask_values.get("include_vehicle_roads", False))
    custom_unmatched_osm = bool(mask_values.get("custom_unmatched_osm", False))

    def apply_alignment_and_rebuild_mask(
        viewer_heightmap_dir,
        viewer_osm_file,
        shift_ew,
        shift_ns,
        progress_callback=None,
        printf=print,
    ):
        if progress_callback is not None:
            progress_callback(2, "Checking whether the aligned mask is already current...")
        status = osm_mask_alignment.get_alignment_status(
            viewer_heightmap_dir,
            viewer_osm_file,
            shift_ew,
            shift_ns,
            auto_red_enabled,
            auto_red_buffer,
            include_vehicle_roads=include_vehicle_roads,
            custom_unmatched_osm=custom_unmatched_osm,
        )
        if status.get("state") == "current":
            if progress_callback is not None:
                progress_callback(100, "The aligned mask is already current.")
            return {
                "action": "already_current",
                "message": (
                    "mask.png already matches this CFS alignment. "
                    "Existing manual mask edits were preserved."
                ),
            }

        return osm_mask_alignment.rebuild_aligned_mask(
            viewer_heightmap_dir,
            viewer_osm_file,
            shift_ew,
            shift_ns,
            auto_red_mask_enabled=auto_red_enabled,
            auto_red_mask_buffer_m=auto_red_buffer,
            include_vehicle_roads=include_vehicle_roads,
            custom_unmatched_osm=custom_unmatched_osm,
            backup_existing=True,
            printf=printf,
            progress_callback=progress_callback,
        )

    def alignment_rebuild_finished(result, viewer_heightmap_dir, shift_ew, shift_ns):
        global last_alignment_heightmap_dir
        last_alignment_heightmap_dir = str(viewer_heightmap_dir)

        # The parent remains responsive during the worker. If the user changed
        # mask settings in the main window while the CFS rebuild was running,
        # do not briefly label the old settings CURRENT. The import gate still
        # performs the full hash/grid verification before course generation.
        try:
            current = _currentOSMMaskInputs(options_entries_dict)
            unchanged = (
                str(current["local_osm_file"]) == str(local_osm_file)
                and abs(float(current["adjust_ew"]) - float(shift_ew)) <= 0.0051
                and abs(float(current["adjust_ns"]) - float(shift_ns)) <= 0.0051
                and bool(current["auto_red_mask_enabled"]) == auto_red_enabled
                and bool(current.get("custom_unmatched_osm", False)) == custom_unmatched_osm
                and (
                    not auto_red_enabled
                    or abs(float(current["auto_red_mask_buffer_m"]) - auto_red_buffer) <= 0.0051
                )
            )
        except Exception:
            unchanged = False

        if unchanged:
            _markOSMMaskCurrentAfterRebuild(
                viewer_heightmap_dir,
                result,
                printf=printf,
            )
        else:
            _setOSMMaskStatus(
                "OSM alignment mask: STALE - settings changed during rebuild",
                "#a00000",
            )
            printf(
                "Aligned mask finished, but the main-window OSM/mask settings "
                "changed during the rebuild; another rebuild is required."
            )

    osm_alignment_viewer.open_alignment_viewer(
        root,
        heightmap_dir_path,
        local_osm_file,
        options_entries_dict["adjust_ew"],
        options_entries_dict["adjust_ns"],
        printf=printf,
        apply_callback=apply_alignment_and_rebuild_mask,
        apply_finished_callback=alignment_rebuild_finished,
        custom_unmatched_osm=custom_unmatched_osm,
    )


def selectLocalOSMFile(path_var):
    global root

    initial_dir = "."
    if root and hasattr(root, 'filename'):
        initial_dir = root.filename

    osm_file = tk.filedialog.askopenfilename(
        title='Select Local OpenStreetMap Export',
        defaultextension='osm',
        initialdir=initial_dir,
        filetypes=osm_types
    )
    if osm_file:
        path_var.set(osm_file)

def importOSMFile(options_entries_dict, printf):
    global root
    global course_json
    global course_version
    
    if not root or not hasattr(root, 'filename'):
        alert("Select a course directory before importing OSM Flat Course")
        return

    if course_json is None:
        alert("Make sure to import a .course file")
        return

    # There may be many options for this in the future (which splines to add, clear splines?, flatten fairways/greens, etc) so store efficiently
    options_dict = {}

    # Snapshot the current values of the entries dictionary into the options_dict
    # We are reusing the same keys, so try not to change them often
    # All values in the entries_dict must support the get() function
    for key, entry in options_entries_dict.items():
        options_dict[key] = entry.get()

    osm_file = tk.filedialog.askopenfilename(title='Select your OpenStreetMap Export', defaultextension='osm', initialdir=root.filename, filetypes=osm_types)
    if osm_file:
        with open(osm_file, encoding="utf8") as f:
            xml_data = f.read()
            printf("Loading OpenStreetMap Data from " + str(osm_file))
            drawPlaceholder()
            course_json = tgc_image_terrain.generate_flat_course(course_json, xml_data, options_dict=options_dict, 
                printf=printf, course_version=course_version)
            drawCourse(course_json)
            printf("Done Rendering Course Preview")

def setStartupWindowSize(window):
    # Use a large default while respecting the actual desktop resolution.
    # Leave a margin for the taskbar/window chrome and center the window.
    try:
        screen_w = int(window.winfo_screenwidth())
        screen_h = int(window.winfo_screenheight())

        target_w = min(1700, max(1300, screen_w - 80))
        target_h = min(900, max(750, screen_h - 140))

        # Never request a window larger than the usable screen estimate.
        target_w = min(target_w, max(1000, screen_w - 30))
        target_h = min(target_h, max(650, screen_h - 80))

        x = max(0, int((screen_w - target_w) / 2))
        y = max(0, int((screen_h - target_h) / 2))

        window.geometry(
            str(target_w) + "x" + str(target_h) +
            "+" + str(x) + "+" + str(y)
        )
        window.minsize(min(1150, target_w), min(700, target_h))
    except Exception:
        # Safe fallback for unusual display configurations.
        window.geometry("1500x800")


root = tk.Tk()
setStartupWindowSize(root)

style = ttk.Style()
style.theme_create( "TabStyle", parent="alt", settings={
        "TNotebook": {"configure": {"tabmargins": [2, 5, 2, 0] } },
        "TNotebook.Tab": {"configure": {"padding": [30, 5] },}})

style.theme_use("TabStyle")

root.title(TGC_APP_TITLE)

header_frame = Frame(root)
output = Label(header_frame, background="lightgrey", width=75, height=1)
output.pack(side=LEFT)
B = Button(header_frame, text = "Select Course Directory", command = partial(getCourseDirectory, output))
B.pack(side=LEFT)
header_frame.pack(fill=X)

nb = ttk.Notebook(root)

s = ttk.Style()
s.configure('new.TFrame', background='#A9A9A9')

tools = ttk.Frame(nb, style='new.TFrame')
lidar = ttk.Frame(nb, style='new.TFrame')
course = ttk.Frame(nb, style='new.TFrame')
scorecard = ttk.Frame(nb, style='new.TFrame')
nb.pack(fill=BOTH, expand=1)
nb.add(tools, text='Course Tools')
nb.add(lidar, text='Load OSM and Process LiDAR/DEM')
nb.add(course, text='Import Terrain and Features')
nb.add(scorecard, text="Scorecard")

## Tools Tab
image_frame = Frame(tools, width=image_width, height=image_height)
image_frame.pack(anchor=NW, side=LEFT)
canvas = tk.Canvas(image_frame, width=image_width, height=image_height)
canvas.place(x=0,y=0)

bg_color = "darkgrey"
tool_bg = "grey25"
text_fg = "grey90"

# BETA6_WORKFLOW_UI_REORDER_V2
# TGC_BETA6_OSM_CARTPATH_ROAD_SPLIT_V4
# Shared workflow state must exist before both the OSM/LiDAR tab and the
# Import Terrain and Features tab are constructed.
options_entries_dict = {}
check_fg = "black"
check_bg = "grey80"
local_osm_var = tk.StringVar()
options_entries_dict["local_osm_file"] = local_osm_var
options_entries_dict["custom_unmatched_osm"] = tk.BooleanVar(value=False)

tool_buttons_frame = Frame(tools, bg=bg_color)
tool_buttons_frame.pack(side=LEFT, fill=BOTH, expand=1)

ib = Button(tool_buttons_frame, text="Import .course", command=importCourseAction)
ib.pack(pady=5)
eb = Button(tool_buttons_frame, text="Export .course", command=exportCourseAction)
eb.pack(pady=5)

name_frame = Frame(tool_buttons_frame, bg=tool_bg)
Label(name_frame, text="Name", fg=text_fg, bg=tool_bg).pack(side=LEFT, padx=5)
course_name_var = tk.StringVar()
name_entry = tk.Entry(name_frame,textvariable=course_name_var, width=32, justify='left', validate="key")
name_entry['validatecommand'] = (name_entry.register(validateCourseName), '%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
name_entry.configure(state='disabled')
name_entry.configure(disabledbackground="grey50")
name_entry.pack(side=LEFT, padx=10, pady=5)
name_frame.pack(pady=5)

# Buttons that move things
move_frame = Frame(tool_buttons_frame, bg=tool_bg)
Label(move_frame, text="West->East", fg=text_fg, bg=tool_bg).grid(row=0, sticky=W, padx=5)
Label(move_frame, text="South->North", fg=text_fg, bg=tool_bg).grid(row=1, sticky=W, padx=5)
ew = tk.Entry(move_frame, width=10, justify='center')
ew.insert(END, '0.0')
ew.grid(row=0, column=1, padx=5)
ns = tk.Entry(move_frame, width=10, justify='center')
ns.insert(END, '0.0')
ns.grid(row=1, column=1, padx=5)
move_buttons_frame = Frame(move_frame, bg=tool_bg)
mcb = Button(move_buttons_frame, text="Move Course", command=partial(shiftAction, ew, ns, "course"))
mcb.pack(pady=5)
mtb = Button(move_buttons_frame, text="Shift Terrain", command=partial(shiftAction, ew, ns, "terrain"))
mtb.pack(pady=5)
mfb = Button(move_buttons_frame, text="Shift Features", command=partial(shiftAction, ew, ns, "features"))
mfb.pack(pady=5)
move_buttons_frame.grid(row=0, column=2, rowspan=2, padx=10)
move_frame.pack(pady=5)

# Rotation with text field
rotate_frame = Frame(tool_buttons_frame, bg=tool_bg)
Label(rotate_frame, text="Rotation (Degrees)", fg=text_fg, bg=tool_bg).grid(row=0, sticky=W, padx=5)
er = tk.Entry(rotate_frame, width=8, justify='center')
er.insert(END, '0.0')
er.grid(row=0, column=1, padx=5)
rb = Button(rotate_frame, text="Rotate", command=partial(rotateAction, er))
rb.grid(row=0, column=2, padx=10, pady=5)
rotate_frame.pack(pady=5)# TGC_HULKIFY_GUI_V2_SLOPE_LOCK
hulkify_button = Button(
    tool_buttons_frame,
    text="Hulkify Course (+10% Slope-Locked)",
    command=hulkifyAction,
    bg="#2E8B57",
    fg="white",
    activebackground="#246B45",
    activeforeground="white",
)
hulkify_button.pack(pady=5)
# Elevation shift
aeb = Button(tool_buttons_frame, text="Auto Shift Elevations", command=partial(elevateAction, None, True))
aeb.pack(pady=5)

elevate_frame = Frame(tool_buttons_frame, bg=tool_bg)
Label(elevate_frame, text="Down->Up", fg=text_fg, bg=tool_bg).grid(row=0, sticky=W, padx=5)
ee = tk.Entry(elevate_frame, width=8, justify='center')
ee.insert(END, '0.0')
ee.grid(row=0, column=1, padx=5)
etb = Button(elevate_frame, text="Shift Elevations", command=partial(elevateAction, ee))
etb.grid(row=0, column=2, padx=10, pady=5)
elevate_frame.pack(pady=5)

terrain_frame = Frame(tool_buttons_frame, bg=bg_color)
stb = Button(terrain_frame, text="Separate Terrain", command=partial(separateAction, "terrain"))
stb.pack(side=LEFT, padx=5, pady=5)
itb = Button(terrain_frame, text="Insert Terrain File", command=partial(insertAction, "terrain"))
itb.pack(side=LEFT, pady=5)
terrain_frame.pack()

holes_frame = Frame(tool_buttons_frame, bg=bg_color)
shb = Button(holes_frame, text="Separate Holes", command=partial(separateAction, "holes"))
shb.pack(side=LEFT, padx=5, pady=5)
ihb = Button(holes_frame, text="Insert Holes File", command=partial(insertAction, "holes"))
ihb.pack(side=LEFT, pady=5)
holes_frame.pack()

ccb = Button(tool_buttons_frame, text="Combine Course Directory", command=combineAction)
ccb.pack(pady=5)

default_im = ImageTk.PhotoImage(image=iim)
canvas_image = canvas.create_image(0,0,image=default_im,anchor=tk.NW)
root.update()

## Lidar Tab
lidarConsoleOutput = tk.scrolledtext.ScrolledText(master=lidar, wrap=tk.WORD, width=20, height=10, state=DISABLED)
lidarPrintf = partial(tkinterPrintFunction, lidar, lidarConsoleOutput)

# Load the OSM source first so every LiDAR/DEM processing path sees the same
# selected layout before it creates previews or a provisional mask.
localOSMSourceFrame = Frame(lidar, bg=check_bg)
Label(
    localOSMSourceFrame,
    text="Local OSM File (blank = online)",
    fg="black",
    bg=check_bg,
).pack(side=LEFT, padx=(8, 5), pady=7)
local_osm_entry = tk.Entry(
    localOSMSourceFrame,
    width=48,
    textvariable=local_osm_var,
)
local_osm_entry.pack(side=LEFT, padx=5, pady=7)
local_osm_browse = Button(
    localOSMSourceFrame,
    text="Browse...",
    command=partial(selectLocalOSMFile, local_osm_var),
)
local_osm_browse.pack(side=LEFT, padx=(5, 8), pady=7)
customUnmatchedOSMCheck = Checkbutton(
    localOSMSourceFrame,
    text="Custom / Unmatched",
    variable=options_entries_dict["custom_unmatched_osm"],
    fg="black",
    bg=check_bg,
)
customUnmatchedOSMCheck.pack(side=LEFT, padx=(4, 8), pady=7)
Label(
    localOSMSourceFrame,
    text="Ignore OSM location; center layout on selected terrain for CFS alignment",
    fg="black",
    bg=check_bg,
).pack(side=LEFT, padx=(0, 8), pady=7)
localOSMSourceFrame.pack(fill=X, padx=10, pady=(8, 4))

lidarControlFrame = Frame(lidar, bg=tool_bg)

scale_label = Label(lidarControlFrame, text="Map Scale", fg=text_fg, bg=tool_bg)
scale_entry = tk.Entry(lidarControlFrame, width=8, justify='center')
scale_entry.insert(END, 2.0)
epsg_label = Label(lidarControlFrame, text="Force LiDAR Horizontal EPSG (blank = auto)", fg=text_fg, bg=tool_bg)
epsg_entry = tk.Entry(lidarControlFrame, width=8, justify='center')
epsg_entry.insert(END, "")
auto_red_mask_var = tk.BooleanVar()
auto_red_mask_var.set(True)
auto_red_mask_buffer_var = tk.StringVar()
auto_red_mask_buffer_var.set(str(int(AUTO_RED_MASK_BUFFER_DEFAULT_M)))
options_entries_dict["auto_red_mask_enabled"] = auto_red_mask_var
options_entries_dict["auto_red_mask_buffer_m"] = auto_red_mask_buffer_var
lidarbutton = Button(
    lidarControlFrame,
    text="Select Lidar and Generate Heightmap",
    command=partial(
        runLidar,
        scale_entry,
        epsg_entry,
        lidarPrintf,
        auto_red_mask_var,
        auto_red_mask_buffer_var,
    ),
)
dembutton = Button(
    lidarControlFrame,
    text="Select DEM GeoTIFF(s)",
    command=partial(
        runDEM,
        scale_entry,
        lidarPrintf,
        auto_red_mask_var,
        auto_red_mask_buffer_var,
    ),
)

scale_label.pack(side=LEFT, padx=5)
scale_entry.pack(side=LEFT, padx=5)
epsg_label.pack(side=LEFT, padx=5)
epsg_entry.pack(side=LEFT, padx=5)
lidarbutton.pack(side=LEFT, padx=5, pady=5)
dembutton.pack(side=LEFT, padx=5, pady=5)

lidarControlFrame.pack(pady=5)

localTreesOnlyFrame = Frame(lidar, bg=tool_bg)
localTreesOnlyButton = Button(
    localTreesOnlyFrame,
    text="Select Local LAS/LAZ - Trees Only",
    command=partial(
        runLocalLidarTreesOnly,
        scale_entry,
        epsg_entry,
        lidarPrintf,
    ),
)
localTreesOnlyButton.pack(side=LEFT, padx=5, pady=5)
Label(
    localTreesOnlyFrame,
    text=(
        "Keeps the existing DEM terrain; extracts only LiDAR tree "
        "locations/heights and honors Force LiDAR EPSG."
    ),
    fg=text_fg,
    bg=tool_bg,
).pack(side=LEFT, padx=8)
localTreesOnlyFrame.pack(pady=(0, 5))

localGapFillFrame = Frame(lidar, bg=tool_bg)
localGapFillButton = Button(
    localGapFillFrame,
    text="Select Local LAS/LAZ - Fill Missing Terrain",
    command=partial(
        runLocalLidarTerrainGapFill,
        epsg_entry,
        lidarPrintf,
        auto_red_mask_var,
        auto_red_mask_buffer_var,
    ),
)
localGapFillButton.pack(side=LEFT, padx=5, pady=5)
Label(
    localGapFillFrame,
    text=(
        "Uses older/fallback Class-2/Class-8 ground only where the current "
        "heightmap is missing. Valid primary terrain is never overwritten."
    ),
    fg=text_fg,
    bg=tool_bg,
).pack(side=LEFT, padx=8)
localGapFillFrame.pack(pady=(0, 5))

awsEptFrame = Frame(lidar, bg=tool_bg)
awsEptButton = Button(
    awsEptFrame,
    text="USGS AWS EPT From Local OSM",
    command=partial(
        runAwsEptLidar,
        scale_entry,
        epsg_entry,
        lidarPrintf,
        auto_red_mask_var,
        auto_red_mask_buffer_var,
    ),
)
awsEptButton.pack(side=LEFT, padx=5, pady=5)
Label(
    awsEptFrame,
    text=(
        "Public 3DEP cloud LiDAR; Local OSM boundary + " +
        str(int(AWS_EPT_OSM_BUFFER_M)) +
        " m buffer. Downloads cropped LAZ and runs normal LiDAR processing."
    ),
    fg=text_fg,
    bg=tool_bg,
).pack(side=LEFT, padx=8)
awsEptFrame.pack(pady=(0, 5))

lidarMaskFrame = Frame(lidar, bg=tool_bg)
auto_red_mask_buffer_entry = tk.Entry(
    lidarMaskFrame,
    width=6,
    justify='center',
    textvariable=auto_red_mask_buffer_var,
)
autoRedMaskCheck = Checkbutton(
    lidarMaskFrame,
    text="Auto Red Mask",
    variable=auto_red_mask_var,
    fg="black",
    bg="grey80",
)
autoRedMaskCheck.pack(side=LEFT, padx=5)
Label(
    lidarMaskFrame,
    text="Buffer (m):",
    fg=text_fg,
    bg=tool_bg,
).pack(side=LEFT, padx=(8, 2))
auto_red_mask_buffer_entry.pack(side=LEFT, padx=2)
Label(
    lidarMaskFrame,
    text="Minimum 5 m / Maximum 30 m",
    fg=text_fg,
    bg=tool_bg,
).pack(side=LEFT, padx=(4, 8))
Label(
    lidarMaskFrame,
    text="Paints all other terrain red; water is preserved.",
    fg=text_fg,
    bg=tool_bg,
).pack(side=LEFT, padx=8)
lidarMaskFrame.pack(pady=(0, 5))

lidarConsoleOutput.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

## Import Terrain and Features Tab
courseConsoleOutput = tk.scrolledtext.ScrolledText(master=course, wrap=tk.WORD, width=20, height=10, state=DISABLED)
coursePrintf = partial(tkinterPrintFunction, course, courseConsoleOutput)

courseControlFrame = Frame(course, bg=bg_color)

# The OSM source and mask controls were created on the
# Load OSM and Process LiDAR/DEM tab and are shared here.

# OpenStreetMap Options
osmControlFrame = Frame(courseControlFrame, bg=tool_bg)
osmSubFrame = Frame(osmControlFrame, bg=check_bg) # Can disable all OSM Options easily inside of this

options_entries_dict["use_osm"] = tk.BooleanVar()
useOSMCheck = Checkbutton(osmControlFrame, text="Import OpenStreetMap", variable=options_entries_dict["use_osm"], fg=check_fg, bg="grey60")
useOSMCheck['command'] = partial(disableAllChildren, options_entries_dict["use_osm"], osmSubFrame)
useOSMCheck.select() # Default to Checked

Label(osmSubFrame, text="Fine Shift West->East", fg=check_fg, bg=check_bg).grid(row=0, sticky=W, padx=5)
Label(osmSubFrame, text="Fine Shift South->North", fg=check_fg, bg=check_bg).grid(row=1, sticky=W, padx=5)
osmew = tk.Entry(osmSubFrame, width=10, justify='center')
osmew.insert(END, '0.0')
options_entries_dict["adjust_ew"] = osmew
osmns = tk.Entry(osmSubFrame, width=10, justify='center')
osmns.insert(END, '0.0')
options_entries_dict["adjust_ns"] = osmns

options_entries_dict["bunker"] = tk.BooleanVar()
bunkerCheck = Checkbutton(osmSubFrame, text="Import Bunkers", variable=options_entries_dict["bunker"], fg=check_fg, bg=check_bg)
bunkerCheck.select()
options_entries_dict["green"] = tk.BooleanVar()
greenCheck = Checkbutton(osmSubFrame, text="Import Greens", variable=options_entries_dict["green"], fg=check_fg, bg=check_bg)
greenCheck.select()
options_entries_dict["fairway"] = tk.BooleanVar()
fairwayCheck = Checkbutton(osmSubFrame, text="Import Fairways", variable=options_entries_dict["fairway"], fg=check_fg, bg=check_bg)
fairwayCheck.select()
options_entries_dict["range"] = tk.BooleanVar()
rangeCheck = Checkbutton(osmSubFrame, text="Import Driving Ranges", variable=options_entries_dict["range"], fg=check_fg, bg=check_bg)
rangeCheck.select()
options_entries_dict["teebox"] = tk.BooleanVar()
teeboxCheck = Checkbutton(osmSubFrame, text="Import Teeboxes", variable=options_entries_dict["teebox"], fg=check_fg, bg=check_bg)
teeboxCheck.select()
options_entries_dict["rough"] = tk.BooleanVar()
roughCheck = Checkbutton(osmSubFrame, text="Import Rough", variable=options_entries_dict["rough"], fg=check_fg, bg=check_bg)
roughCheck.select()
options_entries_dict["water"] = tk.BooleanVar()
waterCheck = Checkbutton(osmSubFrame, text="Import Water", variable=options_entries_dict["water"], fg=check_fg, bg=check_bg)
waterCheck.select()
options_entries_dict["cartpath"] = tk.BooleanVar()
cartpathCheck = Checkbutton(osmSubFrame, text="Import Cartpaths", variable=options_entries_dict["cartpath"], fg=check_fg, bg=check_bg)
cartpathCheck.select()
options_entries_dict["road"] = tk.BooleanVar()
roadCheck = Checkbutton(osmSubFrame, text="Import Automobile Roads", variable=options_entries_dict["road"], fg=check_fg, bg=check_bg)
roadCheck.deselect()
options_entries_dict["path"] = tk.BooleanVar()
pathCheck = Checkbutton(osmSubFrame, text="Import Walking Paths", variable=options_entries_dict["path"], fg=check_fg, bg=check_bg)
pathCheck.select()
options_entries_dict["hole"] = tk.BooleanVar()
holeCheck = Checkbutton(osmSubFrame, text="Import Holes", variable=options_entries_dict["hole"], fg=check_fg, bg=check_bg)
holeCheck.select()
osm_hole_filter = tk.Entry(osmSubFrame, width=10, justify='center')
options_entries_dict["hole_name_filter"] = osm_hole_filter
options_entries_dict["building"] = tk.BooleanVar()
buildingCheck = Checkbutton(osmSubFrame, text="Import Buildings", variable=options_entries_dict["building"], fg=check_fg, bg=check_bg)
buildingCheck.select()
options_entries_dict["tree"] = tk.BooleanVar()
treeCheck = Checkbutton(osmSubFrame, text="Import Mapped Woods/Trees", variable=options_entries_dict["tree"], fg=check_fg, bg=check_bg)
treeCheck.deselect()

options_entries_dict["optimize_osm_spline_points"] = tk.BooleanVar()
optimizeOSMSplineCheck = Checkbutton(
    osmSubFrame,
    text="Optimize OSM Spline Points",
    variable=options_entries_dict["optimize_osm_spline_points"],
    fg=check_fg,
    bg=check_bg
)
optimizeOSMSplineCheck.select()

osmbutton = Button(osmSubFrame, text="Make Flat Course From OSM File", command=partial(importOSMFile, options_entries_dict, coursePrintf))

osmew.grid(row=0, column=1, padx=5)
osmns.grid(row=1, column=1, padx=5)
bunkerCheck.grid(row=2, columnspan=2, sticky=W, padx=5)
greenCheck.grid(row=3, columnspan=2, sticky=W, padx=5)
fairwayCheck.grid(row=4, columnspan=2, sticky=W, padx=5)
rangeCheck.grid(row=5, columnspan=2, sticky=W, padx=5)
teeboxCheck.grid(row=6, columnspan=2, sticky=W, padx=5)
roughCheck.grid(row=7, columnspan=2, sticky=W, padx=5)
waterCheck.grid(row=8, columnspan=2, sticky=W, padx=5)
cartpathCheck.grid(row=9, columnspan=2, sticky=W, padx=5)
roadCheck.grid(row=10, columnspan=2, sticky=W, padx=5)
pathCheck.grid(row=11, columnspan=2, sticky=W, padx=5)
holeCheck.grid(row=13, columnspan=2, sticky=W, padx=5)
Label(osmSubFrame, text="Match Hole Names", fg=check_fg, bg=check_bg).grid(row=14, sticky=W, padx=5)
osm_hole_filter.grid(row=14, column=1, padx=5)
buildingCheck.grid(row=15, columnspan=2, sticky=W, padx=5)
treeCheck.grid(row=16, columnspan=2, sticky=W, padx=5)
optimizeOSMSplineCheck.grid(row=17, columnspan=3, sticky=W, padx=5, pady=(5,0))
osmbutton.grid(row=19, columnspan=3)

useOSMCheck.pack(padx=10, pady=10)
osmSubFrame.pack(padx=5, pady=5)

# Alignment and mask finalization are intentionally placed before course import.
cfsWorkflowFrame = Frame(courseControlFrame, bg=bg_color)
cfsAlignmentViewerButton = Button(
    cfsWorkflowFrame,
    text="CFS Alignment Viewer...",
    command=partial(openCFSAlignmentViewer, options_entries_dict, coursePrintf),
)
cfsAlignmentViewerButton.pack(side=LEFT, padx=(0, 6))
rebuildAlignedMaskButton = Button(
    cfsWorkflowFrame,
    text="Rebuild Mask from Current OSM Alignment...",
    command=partial(rebuildOSMMaskAction, options_entries_dict, coursePrintf),
)
rebuildAlignedMaskButton.pack(side=LEFT, padx=6)
cfsWorkflowFrame.pack(padx=10, pady=(10, 4))

osm_mask_status_var = tk.StringVar()
osm_mask_status_var.set("OSM alignment mask: select a heightmap folder to verify")
osm_mask_status_label = Label(
    courseControlFrame,
    textvariable=osm_mask_status_var,
    fg="black",
    bg=check_bg,
    justify=LEFT,
    wraplength=760,
)
osm_mask_status_label.pack(padx=10, pady=(0, 5), anchor=W, fill=X)

coursebutton = Button(courseControlFrame, text="Select and Import Heightmap and OSM into Course", command=partial(generateCourseFromLidar, options_entries_dict, coursePrintf))
coursebutton.pack(padx=10, pady=(5, 3))

courseImportReminder = Label(
    courseControlFrame,
    text=(
        "Before importing, finalize the CFS alignment, rebuild the aligned mask, "
        "and complete all intended manual edits to mask.png."
    ),
    fg="black",
    bg=check_bg,
    justify=LEFT,
    wraplength=760,
)
courseImportReminder.pack(padx=10, pady=(0, 8), anchor=W, fill=X)


def _scheduleOSMMaskStatusRefresh(*_args):
    try:
        root.after_idle(
            lambda: refreshOSMMaskAlignmentStatus(options_entries_dict)
        )
    except Exception:
        pass


local_osm_var.trace_add("write", _scheduleOSMMaskStatusRefresh)
options_entries_dict["use_osm"].trace_add("write", _scheduleOSMMaskStatusRefresh)
options_entries_dict["road"].trace_add("write", _scheduleOSMMaskStatusRefresh)
options_entries_dict["custom_unmatched_osm"].trace_add("write", _scheduleOSMMaskStatusRefresh)
auto_red_mask_var.trace_add("write", _scheduleOSMMaskStatusRefresh)
# Re-reading heightmap.npy and hashing the Local OSM on every keystroke would
# make the GUI feel sluggish. Refresh when an editable numeric field is
# committed instead; the import gate always performs a fresh final check.
for _alignment_entry in (osmew, osmns, auto_red_mask_buffer_entry):
    _alignment_entry.bind("<Return>", _scheduleOSMMaskStatusRefresh, add="+")
    _alignment_entry.bind("<FocusOut>", _scheduleOSMMaskStatusRefresh, add="+")

# Other Course Options
courseOptionsFrame = Frame(courseControlFrame, bg=tool_bg)
courseSubFrame = Frame(courseOptionsFrame, bg=check_bg) # Not needed for anything here, but I like the look

Label(courseOptionsFrame, text='Course Options', fg=text_fg, bg=tool_bg).pack(pady=(15,10))

options_entries_dict["add_background"] = tk.BooleanVar()
backgroundCheck = Checkbutton(courseSubFrame, text="Add Background Terrain/Remove Cliffs", variable=options_entries_dict["add_background"], fg=check_fg, bg=check_bg)
backgroundCheck.select()
bgentry = tk.Entry(courseSubFrame, width=10, justify='center')
bgentry.insert(END, '16.0')
options_entries_dict["background_scale"] = bgentry
backgroundCheck['command'] = partial(disableAllChildren, options_entries_dict["add_background"], bgentry)
options_entries_dict["auto_background_landscape"] = tk.BooleanVar()
outsideLevelCheck = Checkbutton(
    courseSubFrame,
    text="Auto Background Landscape (Purple)",
    variable=options_entries_dict["auto_background_landscape"],
    fg=check_fg,
    bg=check_bg
)
outsideLevelCheck.select()

outside_bg_resolution_var = tk.StringVar()
outside_bg_resolution_var.set("48")
options_entries_dict["outside_background_resolution"] = outside_bg_resolution_var
outside_bg_resolution_entry = tk.Entry(
    courseSubFrame,
    width=8,
    justify='center',
    textvariable=outside_bg_resolution_var
)
options_entries_dict["lidar_trees"] = tk.BooleanVar()
lidarTreeCheck = Checkbutton(courseSubFrame, text="Add Trees From Lidar (Experimental)", variable=options_entries_dict["lidar_trees"], fg=check_fg, bg=check_bg)
lidarTreeCheck.deselect()
options_entries_dict["tree_variety"] = tk.BooleanVar()
treeVarietyCheck = Checkbutton(
    courseSubFrame,
    text="Tree Variety (Designer themes; custom profiles use calibrated mix)",
    variable=options_entries_dict["tree_variety"],
    fg=check_fg,
    bg=check_bg
)
treeVarietyCheck.deselect()

tree_profile_var = tk.StringVar()
tree_profile_var.set(tree_profile_manager.DESIGNER_THEME_LABEL)
options_entries_dict["tree_profile"] = tree_profile_var
treeProfileCombo = ttk.Combobox(
    courseSubFrame,
    width=31,
    justify='left',
    textvariable=tree_profile_var,
    state='readonly',
    values=tuple(tree_profile_manager.get_profile_choices())
)

tree_scale_mode_var = tk.StringVar()
tree_scale_mode_var.set(tree_profile_manager.HEROIC_SCALE_MODE)
options_entries_dict["tree_scale_mode"] = tree_scale_mode_var
treeScaleModeCombo = ttk.Combobox(
    courseSubFrame,
    width=20,
    justify='left',
    textvariable=tree_scale_mode_var,
    state='readonly',
    values=(
        tree_profile_manager.LEGACY_SCALE_MODE,
        tree_profile_manager.HEROIC_SCALE_MODE,
        tree_profile_manager.EPIC_SCALE_MODE,
        tree_profile_manager.MYTHIC_SCALE_MODE,
    )
)

options_entries_dict["filter_lidar_trees_50m"] = tk.BooleanVar()
filterLidarTreesCheck = Checkbutton(
    courseSubFrame,
    text="Filter LiDAR Trees: within 50 m of Course Features",
    variable=options_entries_dict["filter_lidar_trees_50m"],
    fg=check_fg,
    bg=check_bg
)
filterLidarTreesCheck.select()

options_entries_dict["lidar_buildings"] = tk.BooleanVar()
lidarBuildingCheck = Checkbutton(
    courseSubFrame,
    text="Add Building Footprints From LiDAR (Class 6)",
    variable=options_entries_dict["lidar_buildings"],
    fg=check_fg,
    bg=check_bg
)
lidarBuildingCheck.deselect()

options_entries_dict["filter_lidar_buildings_50m"] = tk.BooleanVar()
filterLidarBuildingsCheck = Checkbutton(
    courseSubFrame,
    text="Filter LiDAR Buildings: within 50 m of Course Features",
    variable=options_entries_dict["filter_lidar_buildings_50m"],
    fg=check_fg,
    bg=check_bg
)
filterLidarBuildingsCheck.select()
options_entries_dict["fill_water"] = tk.BooleanVar()
fillWaterCheck = Checkbutton(courseSubFrame, text="Fill Holes Under Blue Mask", variable=options_entries_dict["fill_water"], fg=check_fg, bg=check_bg)
fillWaterCheck.deselect()
options_entries_dict["purge_water"] = tk.BooleanVar()
purgeWaterCheck = Checkbutton(courseSubFrame, text="Remove All Terrain Under Blue Mask", variable=options_entries_dict["purge_water"], fg=check_fg, bg=check_bg)
purgeWaterCheck.deselect()


brush_type_var = tk.StringVar()
brush_type_var.set("72")
options_entries_dict["brush_type"] = brush_type_var
brush_type_combo = ttk.Combobox(courseSubFrame, width=8, justify='center',
                                textvariable=brush_type_var, state='readonly',
                                values=("72", "9", "10", "15"))

brush_scale_var = tk.StringVar()
brush_scale_var.set("2")
options_entries_dict["brush_scale"] = brush_scale_var
brush_scale_combo = ttk.Combobox(courseSubFrame, width=8, justify='center',
                                 textvariable=brush_scale_var, state='readonly',
                                 values=("1", "2", "3", "4", "6"))


# Pack the osmControlFrame
courseSubFrame.pack(padx=5, pady=5, fill=X, expand=True)
backgroundCheck.grid(row=0, columnspan=2, sticky=W, padx=5)
Label(courseSubFrame, text="Background Scale", fg=check_fg, bg=check_bg).grid(row=1, column=0, sticky=W, padx=5)
bgentry.grid(row=1, column=1, sticky=W, padx=5)
outsideLevelCheck.grid(row=2, columnspan=2, sticky=W, padx=5, pady=(5,0))
Label(courseSubFrame, text="Purple Background Detail Spacing (m)", fg=check_fg, bg=check_bg).grid(row=3, column=0, sticky=W, padx=5)
outside_bg_resolution_entry.grid(row=3, column=1, sticky=W, padx=5)
lidarTreeCheck.grid(row=4, columnspan=2, sticky=W, padx=5)
treeVarietyCheck.grid(row=5, columnspan=2, sticky=W, padx=5)
Label(courseSubFrame, text="Regional Theme (Designer + Trees + Materials)", fg=check_fg, bg=check_bg).grid(row=6, column=0, sticky=W, padx=5, pady=(5,0))
treeProfileCombo.grid(row=6, column=1, sticky=W, padx=5, pady=(5,0))
Label(courseSubFrame, text="Tree Scale", fg=check_fg, bg=check_bg).grid(row=7, column=0, sticky=W, padx=5)
treeScaleModeCombo.grid(row=7, column=1, sticky=W, padx=5)
filterLidarTreesCheck.grid(row=8, columnspan=2, sticky=W, padx=5)
lidarBuildingCheck.grid(row=9, columnspan=2, sticky=W, padx=5)
filterLidarBuildingsCheck.grid(row=10, columnspan=2, sticky=W, padx=5)
fillWaterCheck.grid(row=11, columnspan=2, sticky=W, padx=5)
purgeWaterCheck.grid(row=12, columnspan=2, sticky=W, padx=5)
Label(courseSubFrame, text="Terrain Brush", fg=check_fg, bg=check_bg).grid(row=14, column=0, pady=(10,3), sticky=W, padx=5)
brush_type_combo.grid(row=14, column=1, pady=(10,3), sticky=W, padx=5)
Label(courseSubFrame, text="Brush Size (meters)", fg=check_fg, bg=check_bg).grid(row=15, column=0, pady=3, sticky=W, padx=5)
brush_scale_combo.grid(row=15, column=1, pady=3, sticky=W, padx=5)
Label(courseSubFrame, text="Brushes: 72 / 9 / 10 / 15", fg=check_fg, bg=check_bg).grid(row=16, columnspan=2, sticky=W, padx=5)
Label(courseSubFrame, text="Terrain Generation: Dense / Original only", fg=check_fg, bg=check_bg).grid(row=17, columnspan=2, sticky=W, padx=5)

# Pack the two option frames side by side
osmControlFrame.pack(side=LEFT, anchor=N, padx=5)
courseOptionsFrame.pack(side=LEFT, anchor=N, padx=5, fill=X, expand=True)

# Pack the big frames side by side
courseControlFrame.pack(side=LEFT, padx=5, pady=5, fill=tk.BOTH, expand=True)
courseConsoleOutput.pack(side=LEFT, padx=5, pady=5, fill=tk.BOTH, expand=True)

root.mainloop()


